### About

An interactive map showing users of the [Leaflet](http://leaflet.cloudmade.com/) mapping library. Live map at [http://users.leafletjs.com](http://users.leafletjs.com/).

### Dependencies

- [Leaflet](http://leaflet.cloudmade.com/)
- [Twitter Bootstrap](http://twitter.github.com/bootstrap/)
- [PHP with PDO_SQLITE enabled](http://php.net/manual/en/ref.pdo-sqlite.php)