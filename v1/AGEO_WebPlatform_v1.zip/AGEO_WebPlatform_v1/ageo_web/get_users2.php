
<?php
//$db = new PDO('sqlite:leaflet.sqlite');

$db = mysqli_connect("localhost", "root", "", ""); 

 

//$sql = "select id, name, longitude, latitude, time, type, rain, wet, casualty, comments from user_info;";
//$sql = "select * from user_info;";
$sql = "select * from user_info where id>404;";
//$sql = "select * from user_info where id<230 or id>402;";




$result = $db->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
$rows = array();

  while($row = $result->fetch_assoc()) {
    //echo "id: " . $row["id"]. " - Name: " . $row["name"]. " " . $row["phone_number"]. "<br>";
$rows[] = $row;
  }
} else {
  echo "0 results";
}

print json_encode($rows);

//$db->close();

/*
$rs = $db->query($sql);
if (!$rs) {
    echo "An SQL error occured.\n";
    exit;
}

echo 'sik';

$rows = array();
while($r = $rs->fetch(PDO::FETCH_ASSOC)) {
    $rows[] = $r;
}
print json_encode($rows);
*/
$db = NULL;
?>
