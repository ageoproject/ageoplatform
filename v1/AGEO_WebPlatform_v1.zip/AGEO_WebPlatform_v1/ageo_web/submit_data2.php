<?php

//Define your Server host name here.
$HostName = "localhost";
 
//Define your MySQL Database Name here.
$DatabaseName = "id11189654_flutter_db";
 
//Define your Database User Name here.
$HostUser = "id11189654_root";
 
//Define your Database Password here.
$HostPass = "1234567890"; 

// Creating MySQL connection.
//$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$con = mysqli_connect("localhost", "root", "mysqlp99", "ageo_init");  

 
// Storing the received JSON in $json.
$json = file_get_contents('php://input');
 
// Decode the received JSON and store into $obj
$obj = json_decode($json,true);
 
// Getting name from $obj.
$name = $obj['name'];
 
// Getting email from $obj.
$longitude = $obj['longitude'];
 
// Getting phone number from $obj.
$latitude = $obj['latitude'];

$altitude = $obj['altitude'];
 
/*

  if (isset($_POST[$obj['longitude']])) {
$longitude = '31';
  }

  if (isset($_POST[$obj['latitude']])) {
$latitude = '31';
  }

  if (isset($_POST[$obj['altitude']])) {
$altitude = '31';
  }
*/



//    $image = $_POST['image'];
//    $name = $_POST['name'];
$name = $obj['name'];
$image = $obj['image'];
$time = $obj['time'];

$type = $obj['type'];
$rain = $obj['rain'];
$wet = $obj['wet'];
$casualty = $obj['casualty'];
$comments = $obj['comments'];


$cH = $obj['cHeading']; 
$cA = $obj['cAccuracy'];
$aX = $obj['aX'];
$aY = $obj['aY'];
$aZ = $obj['aZ'];
$gX = $obj['gX'];
$gY = $obj['gY'];
$gZ = $obj['gZ'];
$mX = $obj['mX'];
$mY = $obj['mY'];
$mZ = $obj['mZ'];
$pO = $obj['pOrient'];

 
    $realImage = base64_decode($image);

//$dir = __DIR__ . '/img/'. $name. '.png';
$dir = __DIR__ . '/img/usr_img/'. $name;

//echo '1- '.$realImage.' </br>';
//echo '2- '.getcwd().' </br>';
//echo '8- '.__DIR__.' </br>';
//echo '3- '.realpath().' </br>';
 
//echo $dir;

//echo $image;
//echo $realImage;

    $f = file_put_contents($dir,$realImage);



//if ($f) print 'oldu';
//else print 'olmadi';
 
    //echo "Image Uploaded Successfully.";
 


//echo strlen($image);

// Creating SQL query and insert the record into MySQL database table.
//$Sql_Query = "insert into user_info (name,email,phone_number,image) values ('$name','$email','$phone_number', now())";
//$Sql_Query = "insert into user_info (name,email,phone_number,image) values ('$name','$email','$phone_number', UTC_TIMESTAMP())";
$Sql_Query = "insert into user_info (name,longitude,latitude,altitude,time,type,rain,wet,casualty,comments,cHeading,cAccuracy,aX,aY,aZ,gX,gY,gZ,mX,mY,mZ,pOrient) values ('$name','$longitude','$latitude','$altitude','$time','$type','$rain','$wet','$casualty','$comments','$cH','$cA','$aX','$aY','$aZ','$gX','$gY','$gZ','$mX','$mY','$mZ','$pO')";

 
 

 if(mysqli_query($con,$Sql_Query)){
 
	 // On query success it will print below message.
	$MSG = 'Data Successfully Submitted.' ;
	 
	// Converting the message into JSON format.
	$json = json_encode($MSG);
	 
	// Echo the message.
	 echo $json ;
 
 }
 else{
 
	echo 'Try Again';
	echo $type;
	echo $rain;
	echo $wet;
	echo $casualty;
	echo $comments;

	//echo ' heading '.$cH; 
	//echo ' accur '.$cA;
	//echo ' ax '.$aX;
	//echo ' ay '.$aY;
	//echo ' az '.$aZ;
	//echo ' gx '.$gX;
	//echo ' gy '.$gY;
	//echo ' gz '.$gZ;
	//echo ' mx '.$mX;
	//echo ' my '.$mY;
	//echo ' mz '.$mZ;
	//echo ' po '.$pO;

echo substr($Sql_Query,80);

 
 }


 mysqli_close($con);


?>



