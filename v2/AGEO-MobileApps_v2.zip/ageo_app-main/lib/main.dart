import 'dart:io';

import 'package:ageo_upload_cross/CaptureScreen.dart';
import 'package:ageo_upload_cross/LocationDate.dart';
import 'package:flutter/material.dart';

import 'AboutScreen.dart';
import 'ContactScreen.dart';
import 'SplashScreen.dart';
import 'FirstSceen.dart';
import 'PartnersScreen.dart';
import 'EventSelector.dart';



void main() {
  HttpOverrides.global = new MyHttpOverrides();

  runApp(const MyApp());
}

class MyHttpOverrides extends HttpOverrides{
  @override
  HttpClient createHttpClient(SecurityContext? context){
    return super.createHttpClient(context)
      ..badCertificateCallback = (X509Certificate cert, String host, int port)=> true;
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);


  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AGEO Main Menu',
      debugShowCheckedModeBanner: false,
      //theme: ThemeData(primarySwatch: Colors.red),
      theme: ThemeData(primarySwatch: Colors.blue),
      home: SplashScreen(),initialRoute: '/',
      routes: {
        // When navigating to the "/" route, build the FirstScreen widget.
        '/first': (context) => FirstScreen(),
        // When navigating to the "/second" route, build the SecondScreen widget.
        '/select': (context) => EventSelector(),
        '/contact': (context) => ContactScreen(),
        '/about': (context) => AboutScreen(),
        '/partners': (context) => PartnersScreen(),
        '/location': (context) => LocationDateScreen(evenType: ''),
        '/capture': (context) => CaptureScreen(evenType: '',curLat: 33.33, curLon: 33.33,curAlt: 10, dt: '',rain: 'No', cas: 'No',),
      },
    );
  }
}


