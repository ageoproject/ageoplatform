// ignore: file_names
// ignore: file_names
//import 'package:blog_app/models/ImageUploadModel.dart';
//import 'dart:html';
import 'dart:async';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as Path;
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import 'package:http/http.dart' as http;

import 'package:flutter_compass/flutter_compass.dart';
import 'package:motion_sensors/motion_sensors.dart';


//import 'package:file_picker/file_picker.dart' as vazgec;
import 'package:url_launcher/url_launcher.dart';

import 'Earthquake3.dart';


class CaptureScreen extends StatefulWidget {

  String evenType;
  double curLat;
  double curLon;
  double curAlt;
  String dt;
  String rain;
  String cas;

  CaptureScreen({Key? key,required this.evenType, required this.curLat, required this.curLon, required this.curAlt, required this.dt, required this.rain, required this.cas}) : super(key: key);



  @override
  _SingleImageUploadState createState() {
    return _SingleImageUploadState(this.evenType,this.curLat,this.curLon,this.curAlt, this.dt, this.rain, this.cas);
  }
}

class _SingleImageUploadState extends State<CaptureScreen> {

  bool visible=false;
  bool visibleSens = true;
  bool visibleSend = false;

  String base64Image = '';
  String base64Image2 = '';
  String base64Image3 = '';
  String fileName = 'x';
  String fileName2 = 'x';
  String fileName3 = 'x';

  String status = '';
  String errMessage = 'Error Uploading Image';

  /*
  var wetValue = '';
  var rainTypeValue = '';
  var casualtyValue = '';
   */


  //commentsController.text = '';


  String evenType;
  double curLat;
  double curLon;
  double curAlt;
  String dt;
  String rain;
  String cas;
  _SingleImageUploadState(this.evenType,this.curLat,this.curLon,this.curAlt, this.dt, this.rain, this.cas);

  // ignore: deprecated_member_use
  List<Object> images = <Object>[];
  //PickedFile? _imageFile;
  //XFile _imageFile2;
  XFile? _imageFile;

  void _setImageFileListFromFile(XFile? value) {
    if (value == null) {
      _imageFile = null;
    } else {
      _imageFile = <XFile>[value] as XFile?;
    }
  }

  //File test;
  //File? test =  getImageFileFromAssets();
  final ImagePicker _picker = ImagePicker();


  File getImageFileFromAssets()  {
    final byteData =  rootBundle.load('images/ageo_transparent.png');

print('salakmisin1');
    //final file = File('${(await getTemporaryDirectory()).path}images/ageo_transparent.png');
    final file = File(Path.absolute('').toString()+'images/ageo_transparent.png');
    print('salakmisin2');
    //await file.writeAsBytes(byteData.buffer.asUint8List(byteData.offsetInBytes, byteData.lengthInBytes));

    print('salakmisin 2 ' +file.path );
    return file;
  }


  var eventTypeValue;
  var rainTypeValue;
  var wetValue;
  var casualtyValue;
  var commentsValue;
  var orientation;
  final _streamSubscriptions = <StreamSubscription<dynamic>>[];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      //images.add(ImageUploadModel(uploading: false, imageFile: test, imageUrl: '', isUploaded: false));
      //images.add(ImageUploadModel(uploading: false, imageFile: test, imageUrl: '', isUploaded: false));
      //images.add(ImageUploadModel(uploading: false, imageFile: getImageFileFromAssets() as File, imageUrl: '', isUploaded: false));
      //images.add(ImageUploadModel(uploading: false, imageFile: getImageFileFromAssets() as File, imageUrl: '', isUploaded: false));
      //images.add(ImageUploadModel(uploading: false, imageFile: getImageFileFromAssets() as File, imageUrl: '', isUploaded: false));
      //images.add(ImageUploadModel(uploading: false, imageFile: getImageFileFromAssets() as File, imageUrl: '', isUploaded: false));
      images.add("Add Image");
      images.add("Add Image");
      images.add("Add Image");
      fileName='x';
      fileName2='x';
      fileName3='x';
      //images.add("Add Image");
    });



    _streamSubscriptions.add(
      motionSensors.accelerometer.listen(
        //accelerometerEvents.listen(
            (AccelerometerEvent event) {
          setState(() {
            //_accelerometerValues = <double>[event.x, event.y, event.z];
          });
        },
      ),
    );
    _streamSubscriptions.add(
      motionSensors.gyroscope.listen(
        //gyroscopeEvents.listen(
            (GyroscopeEvent event) {
          /*
          setState(() {
            //_gyroscopeValues = <double>[event.x, event.y, event.z];
          });

               */
        },
      ),
    );
    _streamSubscriptions.add(
      motionSensors.userAccelerometer.listen(
        //userAccelerometerEvents.listen(
            (UserAccelerometerEvent event) {
          /*
          setState(() {
            //_userAccelerometerValues = <double>[event.x, event.y, event.z];
          });

               */
        },
      ),
    );
    _streamSubscriptions.add(
      motionSensors.magnetometer.listen(
        //userAccelerometerEvents.listen(
            (MagnetometerEvent event) {
          /*
          setState(() {
            _magnetometerValues = <double>[event.x, event.y, event.z];
          });

               */
        },
      ),
    );

  }

  String evenText='';
  String cLastReadValue = '';
  String cAccuracyValue = '';
  String cLastReadValue2 = '';
  String cAccuracyValue2 = '';
  String cLastReadValue3 = '';
  String cAccuracyValue3 = '';

  String aXValue = '';
  String aYValue = '';
  String aZValue = '';

  String aXValue2 = '';
  String aYValue2 = '';
  String aZValue2 = '';
  String aXValue3 = '';
  String aYValue3 = '';
  String aZValue3 = '';

  String gXValue = '';
  String gYValue = '';
  String gZValue = '';

  String mXValue = '';
  String mYValue = '';
  String mZValue = '';

  String gXValue2 = '';
  String gYValue2 = '';
  String gZValue2 = '';

  String mXValue2 = '';
  String mYValue2 = '';
  String mZValue2 = '';

  String gXValue3 = '';
  String gYValue3 = '';
  String gZValue3 = '';

  String mXValue3 = '';
  String mYValue3 = '';
  String mZValue3 = '';


  String phoneOrient = '';
  String phoneOrient2 = '';
  String phoneOrient3 = '';


  /*
  'wet': wetValuex,
  'rain': rainTypeValuex,
  'casualty': casualtyValuex,
  'comments': commentsValuex,

   */



  @override
  Widget build(BuildContext context) {

    if (evenType.compareTo('buildingsettlement')==0)
    {
      evenText='Building Settlement';
    }
    else
    {
      evenText = evenType.substring(0,1).toUpperCase()+evenType.substring(1,evenType.length);
    }

    return //new MaterialApp(
      //home:
    new Scaffold(
        appBar: new AppBar(
          centerTitle: true,
          //title: Text('Capture Photo of ' + evenText + ' Event'),
          title: MediaQuery.of(context).size.width > 700 ? Text('Capture Photo of ' + evenText,) : Text('Capture Photo of ' + evenText,style: TextStyle(fontSize: 15),),

          //title: Text('Pick Location & Date for ' + evenText + ' Event'),
        ),
        body:
        Container(
          //width: MediaQuery.of(context).size.width * 0.8,
          //height: MediaQuery.of(context).size.height * 0.5,
          //width: MediaQuery.of(context).size.width * 0.8,
        decoration: BoxDecoration(
    gradient: LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Colors.lightBlueAccent, Colors.white])
    ),

    child:
        Column(children: <Widget>[
          Expanded(
            child:
    ListView(
      shrinkWrap: true,
      padding: EdgeInsets.all(5.0),
      //padding: EdgeInsets.only(left:MediaQuery.of(context).size.width * 0.1,right:MediaQuery.of(context).size.width * 0.1),
      children: <Widget>[
            //Divider(height: 5),


          //Container(
        // here
        //height: BoxFit.fitHeight,
          //height: MediaQuery.of(context).size.height * 0.4,
          //width: MediaQuery.of(context).size.width * 0.8,

          //child:


            //Expanded(
              //child:
              buildGridView(),

          //),
        //),
        Divider(height: 2),

        Visibility(
            visible: !visibleSend && !visibleSens,
            child: !visible ?
            Center(child:Text('Please select or capture at least 1 photo',style: TextStyle(color: Colors.red) ,)):
            Center(child:Text('Please wait for sending to finish.',style: TextStyle(color: Colors.red) ,))


        ),


        TextFormField(
          //enabled: _isEnable,
            maxLines: MediaQuery.of(context).size.width > 700 ? 2 : 5,
            decoration: InputDecoration(
              //border: UnderlineInputBorder(),
                border: OutlineInputBorder(),
                labelText: 'Any extra comments ?',
                hintText: "Please enter any extra comments about the event here..."),
            //controller: commentsController,
            onChanged: (var newval){
              setState((){
                commentsValue = newval;
                //_DBupdate(imgmd5,'comments',newval);
                //commentsController.text = newval.toString();
              });

            }


        ),
        //Divider(height: MediaQuery.of(context).size.width > 700 ? 10 : 200),
        /*
        Visibility(
          visible: visibleSens && visibleSend,
          child:
          RaisedButton(
            onPressed: webCall,
            color: Colors.green,
            textColor: Colors.white,

            padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
            child: Text('Report to AGEO', style: TextStyle(fontSize: 20),),
            //child: Text('Click Here To Submit Data To Server'),
          ),),

         */



            /*
            Divider(height: 15),
            Container(
                //width: 300.00,
                width: MediaQuery.of(context).size.width * 0.8,
                child:TextFormField(
                    //enabled: _isEnable,
                    maxLines: 10,
                    decoration: InputDecoration(
                      //border: UnderlineInputBorder(),
                        border: OutlineInputBorder(),
                        labelText: 'Any extra comments ?',
                        hintText: "Please enter any extra comments about the event here..."),
                    //controller: commentsController,
                    onChanged: (var newval){
                      setState((){
                        //casualtyValue = newval;
                        //_DBupdate(imgmd5,'comments',newval);
                        //commentsController.text = newval.toString();
                      });

                    }


                )),

             */
            //Divider(height: 10),


            //Divider(height: 1),
          ],
        ),
        ),

          Align(
            alignment: Alignment.bottomCenter,
            child:
            Column(children:[
              Divider(height: 15,thickness: 0,),


              Visibility(
                visible: visible,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    /*
            Spacer(),
            Text(_versionName),
            Spacer(
              flex: 2,
            ),

             */
                    CircularProgressIndicator(),
                    /*
            Spacer(
              flex: 2,
            ),
            */
                    Text('Sending... Please wait', style: TextStyle(color: Colors.red),),
                    /*
            Spacer(),

             */
                    //])
                  ],
                ),),
              /*
        Visibility(
            visible: visible,
            child: Container(
                margin: EdgeInsets.only(bottom: 30),
                child: CircularProgressIndicator()
            )
        ),


        Visibility(
            visible: visible,
            child:
            Text('Sending... Please wait.')
        ),
        */
              Visibility(
                //visible: visibleSens && visibleSend,
                  child:
                  ElevatedButton(
                    child: Text(
                      //"Report to AGEO",
                        "Send to AGEO",
                        //"               Report to AGEO               ".toUpperCase(),
                        style: TextStyle(fontSize: 20)
                    ),
                    style: ButtonStyle(
                        foregroundColor: !visibleSend ? MaterialStateProperty.all<Color>(Colors.white.withOpacity(0.3)) : MaterialStateProperty.all<Color>(Colors.white),
                        backgroundColor: !visibleSend ? MaterialStateProperty.all<Color>(Colors.teal.withOpacity(0.3)) : MaterialStateProperty.all<Color>(Colors.teal),
                        //color: !visibleSend ? Colors.teal.withOpacity(0.3) : Colors.teal,
                        //textColor: !visibleSend ? Colors.white.withOpacity(0.3) : Colors.white,
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              //borderRadius: BorderRadius.zero,
                                borderRadius: BorderRadius.circular(18.0),
                                side: BorderSide(color: Colors.teal)
                            )
                        )
                    ),
                    onPressed: !visibleSend ? () {int thisisnotwhatyouarelookingfor=0; setState(() {visibleSens=false;});} : webCall,
                    //onPressed: () { Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));},
                    //onPressed: () => null
                  )
                /*
          RaisedButton(
            //onPressed: (){int sizede=0;}/*webCall*/,
            onPressed: !visibleSend ? () {int thisisnotwhatyouarelookingfor=0; setState(() {visibleSens=false;});} : webCall,

            //color: !visibleSend ? Colors.grey : Colors.teal,
            //textColor: !visibleSend ? Colors.blueGrey : Colors.white,
            color: !visibleSend ? Colors.teal.withOpacity(0.3) : Colors.teal,
            textColor: !visibleSend ? Colors.white.withOpacity(0.3) : Colors.white,


            padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
            child: Text('Report to AGEO', style: TextStyle(fontSize: 20),),
            //child: Text('Click Here To Submit Data To Server'),
          ),
             */

              ),
              //Divider(height:100)

              Divider(
                height: 15,
                thickness: 0,
              ),
            ]),),
        ]),
      ),
    );
      //);
  }

  @override
  void deactivate() {
    super.deactivate();
  }

  @override
  void dispose() {

    /*
    maxWidthController.dispose();
    maxHeightController.dispose();
    qualityController.dispose();

    nameController.dispose();
    emailController.dispose();
    phoneNumberController.dispose();
    wetController.dispose();
    eventTypeController.dispose();
    rainController.dispose();
    casualtyController.dispose();
    commentsController.dispose();
    orientationController.dispose();
    longController.dispose();
    latController.dispose();
    altController.dispose();
    locTController.dispose();
    utcTController.dispose();
    cLastReadController.dispose();
    cAccuracyController.dispose();
    aXController.dispose();
    aYController.dispose();
    aZController.dispose();
    gXController.dispose();
    gYController.dispose();
    gZController.dispose();
    mXController.dispose();
    mYController.dispose();
    mZController.dispose();
    phoneOrientationController.dispose();

     */


    super.dispose();


    for (final subscription in _streamSubscriptions) {
      subscription.cancel();
    }


  }

  Widget _previewImage(filez) {

      if (kIsWeb) {
        // Why network?
        // See https://pub.dev/packages/image_picker#getting-ready-for-the-web-platform
        return Image.network(filez!.path);
      } else {

        //return Image.file(File(filez!.path));
        return Image.file(File(filez!.path),fit: BoxFit.scaleDown,height: double.infinity, width: double.infinity,);
        //return Image.file(File(filez!.path),height:MediaQuery.of(context).size.height/3);//,);
          /*
          Semantics(
          //child: Image.file(File(_imageFile!.path),fit: BoxFit.scaleDown ,    height: double.infinity, width: double.infinity,),
            child: Image.file(File(filez!.path),height:MediaQuery.of(context).size.height/3), //, width:MediaQuery.of(context).size.height/3),
            label: 'image_picker_example_picked_image');

           */
      }
  }


  Future<void> retrieveLostData() async {
    final LostDataResponse response = await _picker.retrieveLostData();
    if (response.isEmpty) {
      return;
    }
    if (response.file != null) {

        setState(() {
          if (response.files == null) {
            _setImageFileListFromFile(response.file);
          } else {
            _imageFile = response.files as XFile?;
          }
        });

    } else {
      var _retrieveDataError = response.exception!.code;
    }
  }


   Future webCall() async{

    // Showing CircularProgressIndicator using State.
    setState(() {
      visible = true ;
      visibleSend = false;
    });

    /*
    // Getting value from Controller
    String name = nameController.text;
    String email = emailController.text;
    String phoneNumber = phoneNumberController.text;
     */

    String name = 'test';
    String email = 'test';
    String phoneNumber = 'test';

    //String fileName = fileName; //that's a no-no.


    /*
    wetValue = wetController.text;
    eventTypeValue = eventTypeController.text;
    rainTypeValue = rainController.text;
    casualtyValue = casualtyController.text;
    commentsValue = commentsController.text;

     */


    //String wetValuex = wetController.text;
    String wetValuex = '';
    String eventTypeValuex = '';

    if (evenType.compareTo('buildingsettlement')==0)
    {
      eventTypeValuex='Building Settlement';
    }
    else if (evenType.compareTo('rockslide')==0)
    {
      eventTypeValuex='Rockfall';
    }
    else
    {
      eventTypeValuex = evenType.substring(0,1).toUpperCase()+evenType.substring(1,evenType.length);
    }
    //String eventTypeValuex = evenType;
    //bool rainTypeValuex = false;
    String rainTypeValuex = rain;
    wetValuex ='No';
    if (rain.compareTo('Yes')==0){wetValuex='Yes';}
    String casualtyValuex = cas;
    //String casualtyValuex = '';
    //String commentsValuex = commentsController.text;
    //String orientation = orientationController.text;
    String commentsValuex = '';
    String orientation = '';



    /*
    String longValue = longController.text;
    String latValue = latController.text;
    String altValue = altController.text;
     */

    //String longValue = longControllerX;
    //String latValue = latControllerX;
    //String altValue = altControllerX;


    String longValue = curLon.toString();//'33.33';
    String latValue = curLat.toString();//'33.33';
    String altValue = curAlt.toString();//'10';


    String utcTValue = dt;
    String locTValue = '';



    //String utcTValue = utcTHolder;
    //String locTValue = locTHolder;

    //String cLastReadValue = cLastReadControllerX;
    //String cAccuracyValue = cAccuracyController.text;

    //String aXValue = aXControllerX;
    //String aYValue = aYControllerX;
    //String aZValue = aZControllerX;

    //String gXValue = gXControllerX;
    //String gYValue = gYControllerX;
    //String gZValue = gZControllerX;

    //String mXValue = mXControllerX;
    //String mYValue = mYControllerX;
    //String mZValue = mZControllerX;

    //String phoneOrient = phoneOrientationController.text;

    //String fileName = tmpFile.path.split('/').last;
    //print (pickedFile!.path);
    //String base64Image = base64Encode(tmpFile.readAsBytesSync());

    // API URL
    //var url = 'https://aqua.ucd.ie/swim/acclima/submit_data2.php';
    var url = 'https://aqua.ucd.ie/swim/ageo/submit_data2.php';


    // Store all data with Param Name.
    //var data = {'name': name, 'email': email, 'phone_number' : phoneNumber};
    //print('testpppppLAAANNN ' +base64Image.substring(0, 100));
    print('yaa ' +base64Image.length.toString());
    print('yaa2 ' +base64Image2.length.toString());
    print('yaa3 ' +base64Image3.length.toString());


    var data,data2,data3;
    if (fileName.compareTo('x')!=0) {
      print('burdayim giriyorum1');
      //var data = {'image': base64Image, 'name': fileName, 'longitude': longValue, 'latitude' : latValue,'time' : utcTValue,'wet' : wetValue ,'type' : eventTypeValue,'rain' : rainTypeValue, 'casualty' : casualtyValue,'comments' : commentsValue}; //no no wrong
      data = {
        'image': base64Image,
        'name': fileName,
        'longitude': longValue,
        'latitude': latValue,
        'altitude': altValue,
        'time': utcTValue,
        'wet': wetValuex,
        'type': eventTypeValuex,
        'rain': rainTypeValuex,
        'casualty': casualtyValuex,
        'comments': commentsValue,
        'cHeading': cLastReadValue,
        'cAccuracy': cAccuracyValue,
        'aX': aXValue,
        'aY': aYValue,
        'aZ': aZValue,
        'gX': gXValue,
        'gY': gYValue,
        'gZ': gZValue,
        'mX': mXValue,
        'mY': mYValue,
        'mZ': mZValue,
        'pOrient': phoneOrient
      }; //no no wrong
    }
    if (fileName2.compareTo('x')!=0) {
      print('burdayim giriyorum2');
      data2 = {
        'image': base64Image2,
        'name': fileName2,
        'longitude': longValue,
        'latitude': latValue,
        'altitude': altValue,
        'time': utcTValue,
        'wet': wetValuex,
        'type': eventTypeValuex,
        'rain': rainTypeValuex,
        'casualty': casualtyValuex,
        'comments': commentsValue,
        'cHeading': cLastReadValue2,
        'cAccuracy': cAccuracyValue2,
        'aX': aXValue2,
        'aY': aYValue2,
        'aZ': aZValue2,
        'gX': gXValue2,
        'gY': gYValue2,
        'gZ': gZValue2,
        'mX': mXValue2,
        'mY': mYValue2,
        'mZ': mZValue2,
        'pOrient': phoneOrient2
      }; //no no wrong
    }
    if (fileName3.compareTo('x')!=0) {
      print('burdayim giriyorum3');
      data3 = {
        'image': base64Image3,
        'name': fileName3,
        'longitude': longValue,
        'latitude': latValue,
        'altitude': altValue,
        'time': utcTValue,
        'wet': wetValuex,
        'type': eventTypeValuex,
        'rain': rainTypeValuex,
        'casualty': casualtyValuex,
        'comments': commentsValue,
        'cHeading': cLastReadValue3,
        'cAccuracy': cAccuracyValue3,
        'aX': aXValue3,
        'aY': aYValue3,
        'aZ': aZValue3,
        'gX': gXValue3,
        'gY': gYValue3,
        'gZ': gZValue3,
        'mX': mXValue3,
        'mY': mYValue3,
        'mZ': mZValue3,
        'pOrient': phoneOrient3
      }; //no no wrong
    }




/*
    ModelAGEO data3 = ModelAGEO(
        id: fileName, image: base64Image, name: fileName, longitude: longValue, latitude : latValue,altitude: altValue, time : utcTValue,wet : wetValuex ,type : eventTypeValuex,rain: rainTypeValuex,casualty: casualtyValuex,comments: commentsValuex, cHeading : cLastReadValue, cAccuracy: cAccuracyValue, aX: aXValue, aY: aYValue, aZ: aZValue, gX: gXValue, gY: gYValue, gZ: gZValue, mX: mXValue, mY: mYValue, mZ: mZValue, pOrient: phoneOrient

    );

 */



    //var data = {'image': base64Image, 'name': fileName, 'email': longValue, 'phone_number' : latValue}; //yes
    //var data = {'image': utcTValue, 'name': fileName, 'email': longValue, 'phone_number' : latValue}; // to do - fix these please with correct name here and at DB
    //var data = {'name': fileName, 'email': longValue, 'phone_number' : latValue};

    /*
    Future<List<ModelAGEO>> XgetModelList() async {
      await XopenDb();
      final List<Map<String, dynamic>> maps = await _database.query('model');

      return List.generate(maps.length, (i) {
        return ModelAGEO(
            id: maps[i]['id'],
            image: maps[i]['image'],
            name: maps[i]['name'],
            longitude: maps[i]['longitude'],
            latitude: maps[i]['latitude'],
            altitude: maps[i]['altitude'],
            time: maps[i]['time'],
            wet: maps[i]['wet'],
            type: maps[i]['type'],
            rain: maps[i]['rain'],
            casualty: maps[i]['casualty'],
            comments: maps[i]['comments'],
            cHeading: maps[i]['cHeading'],
            cAccuracy: maps[i]['cAccuracy'],
            aX: maps[i]['aX'],
            aY: maps[i]['aY'],
            aZ: maps[i]['aZ'],
            gX: maps[i]['gX'],
            gY: maps[i]['gY'],
            gZ: maps[i]['gZ'],
            mX: maps[i]['mX'],
            mY: maps[i]['mY'],
            mZ: maps[i]['mZ'],
            pOrient: maps[i]['pOrient']);
      });
      // return maps
      //     .map((e) => Model(
      //         id: e["id"], fruitName: e["fruitName"], quantity: e["quantity"]))
      //     .toList();
    }

     */


     var response;
    // Starting Web Call with data.
     if (fileName.compareTo('x')!=0) {
       print ('ve yolluyorum 1');
       response = await http.post(Uri.parse(url), body: json.encode(data));
     }
     if (fileName2.compareTo('x')!=0) {
       print ('ve yolluyorum 2');
       response = await http.post(Uri.parse(url), body: json.encode(data2));
     }
     if (fileName3.compareTo('x')!=0) {
       print ('ve yolluyorum 3');
       response = await http.post(Uri.parse(url), body: json.encode(data3));
     }

    // Getting Server response into variable.
    var message = jsonDecode(response.body);

    print ('error mu vercen ? ' +response.statusCode.toString());
    // If Web call Success than Hide the CircularProgressIndicator.
    if(response.statusCode == 200){
      //if(true){

      if ((MediaQuery.of(context).viewInsets.bottom == 0) == false)
      {
        print ('key?'+ MediaQuery.of(context).viewInsets.bottom.toString());
        FocusManager.instance.primaryFocus?.unfocus();
      }

      setState(() {


        /*
        wetController.clear();
        eventTypeController.clear();
        rainController.clear();
        casualtyController.clear();
        commentsController.clear();

         */

        visible = false;
        visibleSens = false;
        visibleSend = false;
        _imageFile = null;
        //_imageFile3 = null;
        //_location = null;

        /*
        wetController.text = 'Please choose...';
        eventTypeController.text = 'Please choose an event type';
        rainController.text = 'Please choose...';
        casualtyController.text = 'Please choose...';
        commentsController.text = '';

         */
        wetValue = null;
        eventTypeValue = null;
        rainTypeValue = null;
        casualtyValue = null;
        commentsValue = null;
        //commentsController.text = '';

      });

    if (evenType.compareTo('earthquake')==0) {
      Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => Earthquake3(
              evenType: evenType,
              curLat: curLat,
              curLon: curLon,
              curAlt: curAlt,
              dt: dt,
              rain: rain,
              cas: cas)));
    }
    else {
      Navigator.pushNamed(context, '/first');
    }

      // Showing Alert Dialog with Response JSON.
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: new Text(message,style: TextStyle(fontSize: 20,),textAlign: TextAlign.center,),
            actions: <Widget>[
              ElevatedButton(
                child: new Text("Visit AGEO Map", style: TextStyle(fontSize: 20,)),
                style: ButtonStyle(
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.teal),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          //borderRadius: BorderRadius.zero,
                            borderRadius: BorderRadius.circular(18.0),
                            side: BorderSide(color: Colors.teal)
                        )
                    )
                ),
                onPressed: () {

                  if ((MediaQuery.of(context).viewInsets.bottom == 0) == false)
                  {
                    print ('key?'+ MediaQuery.of(context).viewInsets.bottom.toString());
                    FocusManager.instance.primaryFocus?.unfocus();
                  }

                  launch('https://aqua.ucd.ie/swim/ageo/');

                  //Navigator.pushNamed(context, '/first');
                  //Navigator.pushNamed(context, '/second');
                  //Navigator.pushNamed(context, '/first');
                  //Navigator.of(context).pushNamed( 'first');
                  //Navigator.pushReplacementNamed(context, '/first');
                  //Navigator.of(context).pop();

                  /*
                Navigator.push(
                  context,
                  new MaterialPageRoute(
                    builder: (context) => new FirstScreen(),
                  ),
                );
                 */
                },
              ),
              ElevatedButton(
                child: new Text("Return to AGEO App", style: TextStyle(fontSize:20,),),
                style: ButtonStyle(
                  foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  backgroundColor: MaterialStateProperty.all<Color>(Colors.teal),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          //borderRadius: BorderRadius.zero,
                            borderRadius: BorderRadius.circular(18.0),
                            side: BorderSide(color: Colors.teal)
                        )
                    )
                ),
                onPressed: () {

                  if ((MediaQuery.of(context).viewInsets.bottom == 0) == false)
                  {
                    print ('key?'+ MediaQuery.of(context).viewInsets.bottom.toString());
                    FocusManager.instance.primaryFocus?.unfocus();
                  }

                  Navigator.of(context).pop();
                  //Navigator.pushNamed(context, '/first');
                  //Navigator.pushNamed(context, '/second');
                  //Navigator.pushNamed(context, '/first');
                  //Navigator.of(context).pushNamed( 'first');
                  //Navigator.pushReplacementNamed(context, '/first');
                  //Navigator.of(context).pop();

                  /*
                Navigator.push(
                  context,
                  new MaterialPageRoute(
                    builder: (context) => new FirstScreen(),
                  ),
                );
                 */
                },
              ),

            ],
          );
        },
      );

    }
    else
      {
        //Navigator.pushNamed(context, '/first');
/*
'Error occured while Communication with Server with StatusCode : ${response
                .statusCode}');
 */
        // Showing Alert Dialog with Response JSON.
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: new Text('Problems occurred during upload, please try again. StatusCode:' + response.statusCode.toString()),
              actions: <Widget>[
                FlatButton(
                  child: new Text("OK"),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );

      }



  }


  Widget buildGridView() {
    return


      Container(
        // here
        //height: BoxFit.fitHeight,
        height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height * 0.4 : MediaQuery.of(context).size.height * 0.5,
          padding: EdgeInsets.only (left: MediaQuery.of(context).size.width/10,right: MediaQuery.of(context).size.width/10),

          //width: 80,

    child:




    GridView.count(
      //shrinkWrap: false,
//      crossAxisCount: 2,
      crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
      childAspectRatio: MediaQuery.of(context).size.width > 700 ? 1.25: 1,
      //childAspectRatio: MediaQuery.of(context).size.width /(MediaQuery.of(context).size.height / 2),
      children: List.generate(images.length, (index) {
        if (images[index] is ImageUploadModel) {
          print ('ARTIK YETER');
          ImageUploadModel uploadModel = images[index] as ImageUploadModel;
          print ('ARTIK YETER2');
          return Card(
            clipBehavior: Clip.antiAlias,
            child: Stack(
              children: <Widget>[
                _previewImage(uploadModel.imageFile),
                //Image.network(uploadModel.imageFile!.path),

                /*

                Image.file(
                  getImageFileFromAssets(),
                  //uploadModel.imageFile.path,
                  width: 300,
                  height: 300,
                ),

                 */
                Positioned(
                  right: 5,
                  top: 5,
                  child: InkWell(
                    child: Icon(
                      Icons.remove_circle,
                      size: 20,
                      color: Colors.red,
                    ),
                    onTap: () {
                      setState(() {
                        if (index==0)fileName='x';
                        if (index==1)fileName2='x';
                        if (index==2)fileName3='x';
                        images.replaceRange(index, index + 1, ['Add Image']);
                        //images.replaceRange(index, index + 1, [ImageUploadModel(uploading: false, imageFile: getImageFileFromAssets() as File, imageUrl: '', isUploaded: false)]);
                        if (fileName.compareTo('x')==0 && fileName2.compareTo('x')==0 && fileName3.compareTo('x')==0)
                          {
                            visibleSens=false;
                            visibleSend=false;
                          }
                      });
                    },
                  ),
                ),
              ],
            ),
          );
        } else {
          return

                Card(
            color: Colors.grey,
              //child:Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              child:Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Card(
            child: IconButton(
              icon: Icon(Icons.photo_camera),
              onPressed: () {
                _onAddImageClick(index,true);
              },
            ),
          ),
            Card(
              child: IconButton(
                icon: Icon(Icons.folder_shared),
                onPressed: () {
                  _onAddImageClick(index,false);
                },
              ),
            )
          ],));
        }
      }),
    ));
      //);
  }

  Future _onAddImageClick(int index, bool bool) async {
    print('XNAME:salak');
/*

    for (final subscription in _streamSubscriptions) {
      subscription.resume();
      //subscription.
    }

    print('XNAME:compass_testing');
    await _getCompass(index);
    await _getPhoneOrientation(index);
    await _getAccelerometer(index);
    await _getGyroscope(index);
    await _getMagnetometer(index);



    for (final subscription in _streamSubscriptions) {
      subscription.pause();
      //subscription.
    }

 */


try {
  if (bool == true) {
    /*
        print('XNAME:compass_testing');
        await _getCompass(index);
        await _getPhoneOrientation(index);
        await _getAccelerometer(index);
        await _getGyroscope(index);
        await _getMagnetometer(index);
        print('XNAME:compass_boom');

         */


    //_imageFile = await _picker.getImage(source: ImageSource.camera);
    _imageFile = (await _picker.pickImage(source: ImageSource.camera));
  }
  else if (bool == false) {
    //_imageFile = await _picker.getImage(source: ImageSource.gallery);
    _imageFile = (await _picker.pickImage(source: ImageSource.gallery));
  }
  //final _imageFile = await _picker.getImage(source: ImageSource.gallery);

}
     catch (e) {
      setState(() {
        print('pickImageError: '+ e.toString());
        //_pickImageError = e;
      });
    }

    for (final subscription in _streamSubscriptions) {
      subscription.resume();
      //subscription.
    }

    print('XNAME:compass_testing');

    try {
      await _getCompass(index);
    }
    catch(e){
      print('compass error');
    }



    try {
      //if (motionSensors.isOrientationAvailable()==true || motionSensors.isAbsoluteOrientationAvailable()==true) {
      //  print('yes ortient');
        await _getPhoneOrientation(index);
      //}
      //else
      //{
      //  print ('no orient');
      //}
    } catch(e) { print('ori error');}
    try {
      //if (true){
      //if (motionSensors.isAccelerometerAvailable()==true) {
      if (motionSensors.isAccelerometerAvailable()!=true) {
        print('yes acc');
      await _getAccelerometer(index);
      }
      else
        {
          print ('no acc');
        }
    } catch(e) { print('acc error');}
    try {
      if (motionSensors.isGyroscopeAvailable()!=true) {
        print ('yes gyro');
        await _getGyroscope(index);
      }
      else
        {
          print ('no gyro');
        }
    } catch(e) { print('gyr error');}
    try {
      if (motionSensors.isMagnetometerAvailable()!=true) {
        print ('yes magno');
        await _getMagnetometer(index);
      }
      else
      {
        print ('no magno');
      }
    } catch(e) { print('mag error');}



    for (final subscription in _streamSubscriptions) {
      subscription.pause();
      //subscription.
    }




      print('try-end');
      //getFileImage(index);


    setState(()  {
      // ignore: deprecated_member_use
      print('XNAME:salak2 index:' + index.toString());
        getFileImage(index);

    });
  }

  /*
  Future await _onAddImageClick(int index) async {
    setState(() async {

      try {
        // ignore: deprecated_member_use, unused_local_variable
         _imageFile = (await ImagePicker.getImage(source: ImageSource.gallery, maxWidth: 1, maxHeight: 1, imageQuality: 1,)) as PickedFile?;

      //_imageFile = ImagePicker.getImage(source: ImageSource.gallery);
      getFileImage(index);
      } catch (e) {
        setState(() {
          //_pickImageError = e;
        });
      }
    });
  }
  */

  Future<void> _getPhoneOrientation(int i) async {
    String _phoneOrient='';
    setState(() {
      print ('get orientdeyim');

      //_error = null;
      //_loading = true;
    });
    String tmp = 'nori';
    try {
      //final LocationData _locationResult = await location.getLocation();


      tmp = MediaQuery
          .of(context)
          .orientation == Orientation.portrait ? 'Portrait' : 'Landscape';

      /*
      bool oriAvailable =
      await motionSensors.isSensorAvailable(3);

      if (!oriAvailable) {

        tmp = MediaQuery
            .of(context)
            .orientation == Orientation.portrait ? 'Portrait' : 'Landscape';
        print('no orientation sensor is available on the phone, trying the other way');
        //final String tmp = MediaQuery
        //    .of(context)
        //    .orientation == Orientation.portrait ? 'Portrait' : 'Landscape';
      }
      else {
        print('MEEEEE yes ori');

        var tmp_tmp = await motionSensors.screenOrientation.first;
        var tmp_tmp2 = await motionSensors.orientation.first;
        var tmp_tmp3 = await motionSensors.absoluteOrientation.first;
        tmp = tmp_tmp.angle.toString();

        //final String tmp = await motionSensors.screenOrientation.first
        //    .toString();
      }
      */


        //final String tmp = MediaQuery
        //    .of(context)
        //    .orientation == Orientation.portrait ? 'Portrait' : 'Landscape';

        //final CompassEvent tmp = await FlutterCompass.events!.first;
        setState(() {
          //_phoneOrient = tmp;


          if (i == 0) {
            phoneOrient = tmp;
            print('or1' + tmp);
          }
          if (i == 1) {
            phoneOrient2 = tmp;
            print('or2' + tmp);
          }
          if (i == 2) {
            phoneOrient3 = tmp;
            print('or3' + tmp);
          }
          //_lastReadAt = DateTime.now();

          //phoneOrientationController.text = tmp;
          //cAccuracyController.text = tmp.accuracy.toString();


        });
      //}

    } on PlatformException catch (err) {
      setState(() {
        //_error = err.code;
        //_loading = false;
        print ('playform exception[orient]: ' + err.code);
      });
    }
  }

  Future<void> _getCompass(int i) async {
    CompassEvent? _lastRead;
    DateTime? _lastReadAt;

    setState(() {
      //_error = null;
      //_loading = true;
      print ('get compassdayim');
    });

    try {
      //final LocationData _locationResult = await location.getLocation();

      /*
      for (var i=0;i<100;i++)
        {

          bool compAvailablex =
          await motionSensors.isSensorAvailable(i);
          print (i.toString()+ ' : '+ compAvailablex.toString());

        }
       */
      bool compAvailable =
      await motionSensors.isSensorAvailable(11);

      if (!compAvailable)
      {
        print ('SSIKKKK no compass 11');
      }
      else {
        print('MEEEEE yes compass 11');


        final CompassEvent tmp = await FlutterCompass.events!.first;
        setState(() {
          _lastRead = tmp;
          _lastReadAt = DateTime.now();

          print('GET COMPASSTAYIM VE INDEX: ' + i.toString());
          //String cLastReadValue = '';
          //String cAccuracyValue = '';
          //cLastReadControllerX = tmp.headingForCameraMode.toString();
          //cLastReadValue = tmp.headingForCameraMode.toString().substring(0,6);
          //cLastReadController.text = tmp.headingForCameraMode.toString();

          if (tmp.heading == null) {
            print('no compass');
          }
          else {
            print('yes compass');
            if (i == 0) {
              cLastReadValue = tmp.headingForCameraMode.toString();
              cAccuracyValue = tmp.accuracy.toString();
              var cAccuracyValueaa = tmp.heading.toString();
              print('GET COMPASSTAYIM VE INDEX 0 icindeyim: ' + i.toString());
              print('1 '+cLastReadValue);
              print('2 '+cAccuracyValue);
              print('3 '+cAccuracyValueaa);
            }

            if (i == 1) {
              cLastReadValue2 = tmp.headingForCameraMode.toString();
              cAccuracyValue2 = tmp.accuracy.toString();
              var cAccuracyValueaa = tmp.heading.toString();
              print('GET COMPASSTAYIM VE INDEX 1 icindeyim: ' + i.toString());
              print('1 '+cLastReadValue2);
              print('2 '+cAccuracyValue2);
              print('3 '+cAccuracyValueaa);
            }
            if (i == 2) {
              cLastReadValue3 = tmp.headingForCameraMode.toString();
              cAccuracyValue3 = tmp.accuracy.toString();
              var cAccuracyValueaa = tmp.heading.toString();
              print('GET COMPASSTAYIM VE INDEX 2 icindeyim: ' + i.toString());
              print('1 '+cLastReadValue3);
              print('2 '+cAccuracyValue3);
              print('3 '+cAccuracyValueaa);
            }
          }
        });
      }



/*
        setState(() {
        _location = _locationResult;
        _loading = false;

        longController.text = _locationResult.longitude.toString();
        latController.text = _locationResult.latitude.toString();

      });

 */
    } on PlatformException catch (err) {
      setState(() {
        print ('playform exception[compass]: ' + err.code);
        //_error = err.code;
        //_loading = false;
      });
    }
  }

  Future<void> _getAccelerometer(int i) async {
    setState(() {
      print ('get accdeyim');

      //_error = null;
      //_loading = true;
    });
    try {
      //final LocationData _locationResult = await location.getLocation();

      /*
      final CompassEvent tmp = await FlutterCompass.events!.first;
      setState(() {
        _lastRead = tmp;
        _lastReadAt = DateTime.now();

        cLastReadController.text = tmp.headingForCameraMode.toString();
        cAccuracyController.text = tmp.accuracy.toString();


      });

       */

      //final AccelerometerEvent tmp = await accelerometerEvents.first;
      bool accAvailable =
      await motionSensors.isSensorAvailable(1);

      if (!accAvailable)
      {
        print ('SSIKKKK no acc');
      }
      else {
        print('MEEEEE yes acc');

      final AccelerometerEvent tmp = await motionSensors.accelerometer.first;

      setState(() {
        var _accData = tmp;
        //_lastReadAt = DateTime.now();
        if (i == 0) {
          aXValue = tmp.x.toString();
          aYValue = tmp.y.toString();
          aZValue = tmp.z.toString();
        }
        if (i == 1) {
          aXValue2 = tmp.x.toString();
          aYValue2 = tmp.y.toString();
          aZValue2 = tmp.z.toString();
        }
        if (i == 2) {
          aXValue3 = tmp.x.toString();
          aYValue3 = tmp.y.toString();
          aZValue3 = tmp.z.toString();
        }
      });
          }




        //aXController.text = tmp.x.toString().substring(0,6);
        //aYController.text = tmp.y.toString().substring(0,6);
        //aZController.text = tmp.z.toString().substring(0,6);

      //});






/*
        setState(() {
        _location = _locationResult;
        _loading = false;

        longController.text = _locationResult.longitude.toString();
        latController.text = _locationResult.latitude.toString();

      });

 */
    } on PlatformException catch (err) {
      setState(() {
        print ('playform exception[acc]: ' + err.code);
        //_error = err.code;
        //_loading = false;
      });
    }
  }


  Future<void> _getGyroscope(int i) async {
    setState(() {
      print ('get gyrdeyim');
      //_error = null;
      //_loading = true;
    });


    try {
      //final LocationData _locationResult = await location.getLocation();

      /*
      final CompassEvent tmp = await FlutterCompass.events!.first;
      setState(() {
        _lastRead = tmp;
        _lastReadAt = DateTime.now();

        cLastReadController.text = tmp.headingForCameraMode.toString();
        cAccuracyController.text = tmp.accuracy.toString();


      });

       */

      bool gyroAvailable =
      await motionSensors.isSensorAvailable(4);

      if (!gyroAvailable)
      {
        print ('SSIKKKK no gyro');
      }
      else {
        print('MEEEEE yes gyro');


      //final GyroscopeEvent tmp = await gyroscopeEvents.first;
      final GyroscopeEvent tmp = await motionSensors.gyroscope.first;
       //Future<GyroscopeEvent> tmp2 =  motionSensors.gyroscope.first;


        setState(() {
          var _gyrData = tmp;
          //_lastReadAt = DateTime.now();


          if (i == 0) {
            gXValue = tmp.x.toString();
            gYValue = tmp.y.toString();
            gZValue = tmp.z.toString();
          }
          if (i == 1) {
            gXValue2 = tmp.x.toString();
            gYValue2 = tmp.y.toString();
            gZValue2 = tmp.z.toString();
          }
          if (i == 2) {
            gXValue3 = tmp.x.toString();
            gYValue3 = tmp.y.toString();
            gZValue3 = tmp.z.toString();
          }

          //gXController.text = tmp.x.toString().substring(0,6);
          //gYController.text = tmp.y.toString().substring(0,6);
          //gZController.text = tmp.z.toString().substring(0,6);

        });
      }




/*
        setState(() {
        _location = _locationResult;
        _loading = false;

        longController.text = _locationResult.longitude.toString();
        latController.text = _locationResult.latitude.toString();

      });

 */
    } on PlatformException catch (err) {
      setState(() {
        print ('playform exception[gyr]: ' + err.code);
        //_error = err.code;
        //_loading = false;
      });
    }
  }

  Future<void> _getMagnetometer(int i) async {
    setState(() {
      print ('get magdayim');
      //_error = null;
      //_loading = true;
    });
    try {
      //final LocationData _locationResult = await location.getLocation();

      /*
      final CompassEvent tmp = await FlutterCompass.events!.first;
      setState(() {
        _lastRead = tmp;
        _lastReadAt = DateTime.now();

        cLastReadController.text = tmp.headingForCameraMode.toString();
        cAccuracyController.text = tmp.accuracy.toString();


      });

       */

      bool magAvailable =
      await motionSensors.isSensorAvailable(2);

      if (!magAvailable)
      {
        print ('SSIKKKK no mag');
      }
      else {
        print('MEEEEE yes mag');

        //final GyroscopeEvent tmp = await gyroscopeEvents.first;
        final MagnetometerEvent tmp = await motionSensors.magnetometer.first;
        setState(() {
          var _mgnData = tmp;
          //_lastReadAt = DateTime.now();


          if (i == 0) {
            mXValue = tmp.x.toString();
            mYValue = tmp.y.toString();
            mZValue = tmp.z.toString();
          }
          if (i == 1) {
            mXValue2 = tmp.x.toString();
            mYValue2 = tmp.y.toString();
            mZValue2 = tmp.z.toString();
          }
          if (i == 2) {
            mXValue3 = tmp.x.toString();
            mYValue3 = tmp.y.toString();
            mZValue3 = tmp.z.toString();
          }


          //mXController.text = tmp.x.toString().substring(0,6);
          //mYController.text = tmp.y.toString().substring(0,6);
          //mZController.text = tmp.z.toString().substring(0,6);


        });
      }



/*
        setState(() {
        _location = _locationResult;
        _loading = false;

        longController.text = _locationResult.longitude.toString();
        latController.text = _locationResult.latitude.toString();

      });

 */
    } on PlatformException catch (err) {
      setState(() {
        print ('playform exception[mag]: ' + err.code);
        //_error = err.code;
        //_loading = false;
      });
    }
  }

  void getFileImage(int index) async {

    print('XNAME:salak3');
//    var dir = await path_provider.getTemporaryDirectory();
  //PickedFile? test = _imageFile;
  XFile? test = _imageFile;

    print('XNAME:salak4');

/*
    for (final subscription in _streamSubscriptions) {
      subscription.resume();
      //subscription.
    }

    print('XNAME:compass_testing');
    await _getCompass(index);
    await _getPhoneOrientation(index);
    await _getAccelerometer(index);
    await _getGyroscope(index);
    await _getMagnetometer(index);



    for (final subscription in _streamSubscriptions) {
      subscription.pause();
      //subscription.
    }

 */



/*
    vazgec.FilePickerResult? pickedFile;
    //pickedFile = await vazgec.FilePicker.platform.pickFiles();
    //pickedFile = _imageFile as vazgec.FilePickerResult;
    pickedFile = File(test!.path).readAsBytesSync() as vazgec.FilePickerResult?;

print ('olmali');
    var nasil = pickedFile!.files.first.bytes!;
    print(nasil.first);
    print ('olmamali');

    if (pickedFile != null) {
      try {
        setState(() {
          base64Image = pickedFile!.files.first.bytes.toString();
          print (base64Image.substring(0,100));
        });
      } catch (err) {
        print(err);
      }
    } else {
      print('No Image Selected');
    }
*/


    //BURALARDAYDI UNLEMLER
  File _image = File(test!.path);
  //File _image3 = File(test3!.path);
    print('XNAME:salak5');
  //final fileName = 'background_image';
    if (index==0)
      {
        print ('burdayim tekrar giriyorum');
        fileName = test.path.split('/').last.toString();
        //fileName = test3!.path.split('/').last.toString();
      }
    if (index==1)
    {
      print ('burdayim tekrar giriyorum2');
      fileName2 = test.path.split('/').last.toString();
      //fileName2 = test3!.path.split('/').last.toString();
    }
    if (index==2)
    {
      print ('burdayim tekrar giriyorum3');
      fileName3 = test.path.split('/').last.toString();
      //fileName3 = test3!.path.split('/').last.toString();
    }

    //UNLEMLIYDI BUDA
    print('XNAME:salak6');
  var fileNameX = Path.basename(test.path);
  //fileNameX = Path.basename(test3!.path);
    print('XNAME:salak7');
  //print('XNAME: ' +fileNameX);
  //print('XNAME: ' +fileNameX);
  //print('XNAME: ' +fileNameX);
  //print('XNAME: ' +fileNameX);
  print('XNAME: ' +fileNameX);
  //print('XNAME: ' +fileNameX);

    print('hassicktir: ' +fileNameX);
    List<int> imageBytes = _image.readAsBytesSync();
    //List<int> imageBytes3 = _image3.readAsBytesSync();
    print(imageBytes);
    //print(imageBytes3);


    if (index==0)
    {
      print ('burdayim tekrar giriyorum');
      base64Image = base64Encode(imageBytes);
      //base64Image = base64Encode(imageBytes3);

      print('testppppp ' +base64Image.substring(0, 100));
    }
    if (index==1)
    {
      print ('burdayim tekrar giriyorum');
      base64Image2 = base64Encode(imageBytes);
      //base64Image2 = base64Encode(imageBytes3);
      print('testppppp ' +base64Image2.substring(0, 100));
    }
    if (index==2)
    {
      print ('burdayim tekrar giriyorum');
      base64Image3 = base64Encode(imageBytes);
      //base64Image3 = base64Encode(imageBytes3);
      print('testppppp ' +base64Image3.substring(0, 100));
    }







    /*BIG PROBLEM
    https://stackoverflow.com/questions/50036393/how-to-convert-an-image-to-base64-image-in-flutter

    import 'dart:convert';
    List<int> imageBytes = widget.fileData.readAsBytesSync();
    print(imageBytes);
    String base64Image = base64Encode(imageBytes);
    and this is working fine now.

    It is better to read it asynchronously as the image can be very large which may cause blocking of the main thread

    List<int> imageBytes = await widget.fileData.readAsBytes();
    */

    print('XNAME:salak8');
    //final bytes = test!readAsBytes();
    //final bytes2 = File(test!.path).readAsBytesSync();//.readAsBytes();
    //final bytes3 = _image.readAsBytes();
  //final bytes2 = File(test!.path).readAsBytesSync();
    print('XNAME:salak9');

    //UNLEMLYDI BUDA
  print('PATH: ' +test.path);

    //print('PATH3: ' +test3!.path);
  print('NAMEforReal: ' +fileName);
    print('NAME2: ' +fileName2);
    print('NAME3: ' +fileName3);

  //................
  //Directory appDocDir = await getApplicationDocumentsDirectory();
  //String appDocPath = appDocDir.path;
  //print('ADIR: ' +appDocPath);



    /*
    print('XNAME:salak10');
    List<int> imageBytes = _image.readAsBytes() as List<int>;
    print('XNAME:salak11');
    print(imageBytes);
    String base64Image = base64Encode(imageBytes);
    print('XNAME:salak12');

  base64Image = base64Encode(imageBytes);
  print('testppppp ' +base64Image.substring(0, 100));
*/
    //_imageFile.((file) async {

    //final siktirgit = File(test!.path).readAsBytesSync();
    //String base64Image = base64Encode(siktirgit.toList());

    //buralarda biseyler yapman lazim
    //final bytes = File(test!.path).readAsBytesSync();
    //String base64Image =  "data:image/png;base64,"+base64Encode(bytes);

    //print("img_pan : $base64Image");

    //print('before ' + images.first.toString());
    for (var res=0;res<3;res++)
      {
        print('before '+res.toString()+': ' + images.elementAt(res).toString());
        //print('before 0: ' + images.elementAt(0).toString());
        //print('before 1: ' + images.elementAt(1).toString());
        //print('before 2: ' + images.elementAt(2).toString());
        if (images.elementAt(res).toString().compareTo('Add Image')==0)
          {
            print ('bunu eklemeycen');
          }
      }

    //print('before ' + images.elementAt(3).toString());
    //print('before ' + images.last.toString());
      setState(() {
        ImageUploadModel imageUpload = ImageUploadModel(uploading: false, imageFile: _image, imageUrl: '', isUploaded: false);
        imageUpload.isUploaded = false;
        imageUpload.uploading = false;
        imageUpload.imageFile = _image;
        imageUpload.imageUrl = '';
        images.replaceRange(index, index + 1, [imageUpload]);
        visibleSend = true;
        visibleSens = true;
      });

    //print('after ' + images.first.toString());
    //print('after ' + images.indexOf(1).toString());
    print('after 0: ' + images.elementAt(0).toString());
    print('after 1: ' + images.elementAt(1).toString());
    print('after 2: ' + images.elementAt(2).toString());
    //print('after ' + images.last.toString());
    //});
  }
}



class ImageUploadModel {
  bool isUploaded = false;
  bool uploading;
  File imageFile;
  String imageUrl;

  ImageUploadModel({
     required this.isUploaded,
     required this.uploading,
      required this.imageFile,
     required this.imageUrl,
  });
}



