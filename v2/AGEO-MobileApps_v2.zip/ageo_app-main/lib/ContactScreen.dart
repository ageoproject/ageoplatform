import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Contact AGEO'),
        ),


        body:
        Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.blueAccent, Colors.white])
            ),

            child:Center(


              // Add a ListView to the drawer. This ensures the user can scroll
              // through the options in the drawer if there isn't enough vertical
              // space to fit everything.
                child:
                ListView(
                  shrinkWrap: true,
                  padding: EdgeInsets.all(15.0),
                  children: <Widget>[
                    /*Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,

            children:<Widget>[

         */
                    Image(image: AssetImage('images/contact.png',),),
                    Divider(
                      color: Colors.black,
                      height: 20,

                    ),





                    /*
          body:
      Container(
      decoration: BoxDecoration(
      gradient: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Colors.lightBlueAccent, Colors.white])
      ),

      child:
      GridView.count(
      primary: false,
    padding: const EdgeInsets.all(0.1),

    crossAxisSpacing: 0.1,
    mainAxisSpacing: 0.1,
    crossAxisCount: 2,
    children: <Widget>[
          InkWell(
          onTap: () => launch('https://tecnico.ulisboa.pt/en/'),
    child:Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
          //Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),
    Expanded(child:Image.asset("images/partners/p1x.png"),),
    Expanded(child:Text("Instituto Superior Técnico Universidade de Lisboa",textAlign: TextAlign.center,),),
    //Expanded(child:Text("tecnico.ulisboa.pt/en",style: new TextStyle(color: Colors.blue)),),
      //Text("https://tecnico.ulisboa.pt/en/"),

      ],
    ),),
    InkWell(
    onTap: () => launch('http://www.apgeologos.pt/'),
    child:
    Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
    children: <Widget>[
    //Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),
    Expanded(child:Image.asset("images/partners/p2x.png"),),
    Expanded(child:Text("Associação Portuguesa de Geólogos",textAlign: TextAlign.center,),),
    //Expanded(child:Text("www.apgeologos.pt",style: new TextStyle(color: Colors.blue)),),

    ],
    ),),
           */


                    SizedBox(
                      height: 15,
                    ),

                    Text("To contact us or make us aware of AGEO related information, please find us on", textAlign:TextAlign.center, style: Theme.of(context).textTheme.headline5),
                    SizedBox(
                      height: 15,
                    ),
                    InkWell(
                        child:Text("www.ageoatlantic.eu", textAlign:TextAlign.center,style: new TextStyle(color: Colors.blueAccent, fontSize:30), ),
                        onTap: () => launch('https://ageoatlantic.eu/')),
                    SizedBox(
                      height: 15,
                    ),
                    //Expanded(child:
                    Row(mainAxisAlignment : MainAxisAlignment.center,
                        children:[
                          Spacer(flex:30),
                          InkWell(
                              child:Image.asset("images/partners/twitter.png",height: 75, width: 75,),//Text("Twitter", textAlign:TextAlign.center,style: new TextStyle(color: Colors.blue, fontSize:30), ),
                              onTap: () => launch('https://twitter.com/AgeoAtlantic/')),
                          //Text("and"),
                          Spacer(flex:1),
                          InkWell(
                              child:Image.asset("images/partners/facebook.png",height: 75, width: 75,/*fit: BoxFit.contain,*/ ),//Text("Facebook", textAlign:TextAlign.center,style: new TextStyle(color: Colors.blue, fontSize:30),),
                              onTap: () => launch('https://www.facebook.com/ageoatlantic/')),
                          Spacer(flex:30),
                        ]),
                    //),
                    SizedBox(
                      height: 15,
                    ),
                    Divider(
                      color: Colors.black,
                      height: 10,
                    ),

                    //Expanded(child:
                    Row(mainAxisAlignment : MainAxisAlignment.center,
                        children:[
                          Expanded(child:Image(image: AssetImage('images/ageo_transparent2.png',),height: 150,
                            width: 300,),),
                          Expanded(child:Image(image: AssetImage('images/interreg.png',),height: 150,
                            width: 300,),),
                        ])
                    //)
                    /*
        Expanded(child:Image(image: AssetImage('images/ageo_transparent2.png',),height: 30,
                width: 60,)),
        Expanded(child:Image(image: AssetImage('images/interreg.png',),height: 30,
                width: 60,)),
         */

                    /*children: <Widget>[
              Text("About the Interreg Atlantic Area Programme" ,style: Theme.of(context).textTheme.headline6,),
          Image(image: AssetImage('images/contact.png',)),
          Expanded(child:
          InkWell(
              child:Text("To contact us or make us aware of an related event, please find us on Twitter and Facebook", textAlign:TextAlign.center,style: new TextStyle(color: Colors.blue),),
              onTap: () => launch('https://www.facebook.com/ageoatlantic/')),),
        */
                  ],
                )
            )));
  }
}