import 'dart:io';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart' show kIsWeb;


class AGEO_DatabaseHelper {

  static final _databaseName = "ageo_init.db";
  static final _databaseVersion = 1;

  static final table = 'user_info';

  static final columnid= 'id';
  //static final columnimage= 'image';
  static final columnname= 'name';
  static final columnlongitude= 'longitude';
  static final columnlatitude= 'latitude';
  static final columnaltitude= 'altitude';
  static final columntime= 'time';
  static final columnwet= 'wet';
  static final columntype= 'type';
  static final columnrain= 'rain';
  static final columncasualty= 'casualty';
  static final columncomments= 'comments';
  static final columncHeading= 'cHeading';
  static final columncAccuracy= 'cAccuracy';
  static final columnaX= 'aX';
  static final columnaY= 'aY';
  static final columnaZ= 'aZ';
  static final columngX= 'gX';
  static final columngY= 'gY';
  static final columngZ= 'gZ';
  static final columnmX= 'mX';
  static final columnmY= 'mY';
  static final columnmZ= 'mZ';
  static final columnpOrient= 'pOrient';

  //late Database _database;
  late  Database _database;
  // make this a singleton class
  AGEO_DatabaseHelper._privateConstructor();
  static final AGEO_DatabaseHelper instance = AGEO_DatabaseHelper._privateConstructor();

  // only have a single app-wide reference to the database
  //static Database _database;
  Future<Database> get database async {
    //if (_database != null) return _database;
    // lazily instantiate the db the first time it is accessed
    _database = await _initDatabase();
    return _database;
  }

  // this opens the database (and creates it if it doesn't exist)
  _initDatabase() async {

     //documentsDirectory = '' as Directory;

    if (kIsWeb) {
      // Set web-specific directory
    } else {
      Directory documentsDirectory = await getApplicationDocumentsDirectory();
      String path = join(documentsDirectory.path, _databaseName);

      return await openDatabase(path,
          version: _databaseVersion,
          onCreate: _onCreate);
    }

  }

  // SQL code to create the database table
  Future _onCreate(Database db, int version) async {
    await db.execute('''
          CREATE TABLE $table (
            		$columnid TEXT PRIMARY KEY,
            		$columnname TEXT NOT NULL,
		            $columnlongitude TEXT,
            		$columnlatitude TEXT,
		            $columnaltitude TEXT,
		            $columntime TEXT,
		            $columntype TEXT,
		            $columnrain TEXT,
		            $columnwet TEXT,
		            $columncasualty TEXT,
		            $columncomments TEXT,
		            $columncHeading TEXT,
		            $columncAccuracy TEXT,
		            $columnaX TEXT,
		            $columnaY TEXT,
		            $columnaZ TEXT,
		            $columngX TEXT,
		            $columngY TEXT,
		            $columngZ TEXT,
		            $columnmX TEXT,
		            $columnmY TEXT,
		            $columnmZ TEXT,
		            $columnpOrient TEXT
          )
          ''');
  }

  // Helper methods

  // Inserts a row in the database where each key in the Map is a column name
  // and the value is the column value. The return value is the id of the
  // inserted row.
  Future<int> insert(Map<String, dynamic> row) async {

    //_database = await _initDatabase();
    Database db = await instance.database;
    return await db.insert(table, row);
  }

  // All of the rows are returned as a list of maps, where each map is
  // a key-value list of columns.
  Future<List<Map<String, dynamic>>> queryAllRows() async {
    Database db = await instance.database;
    return await db.query(table);
  }

  /*
  Future<List<Map<String, dynamic>>> queryARow(var id) async {
    Database db = await instance.database;
    return await db.query(table, row, where: '$columnid = ?', whereArgs: [id]);
  }
  Future<int> delete(int id) async {
    Database db = await instance.database;
    return await db.delete(table, where: '$columnid = ?', whereArgs: [id]);
  }

   */

  Future<List<Map<String, dynamic>>> queryARow(String id) async {
    Database db = await instance.database;
    return db.query(table, where: "id = ?", whereArgs: [id], limit: 1);
  }

  // All of the methods (insert, query, update, delete) can also be done using
  // raw SQL commands. This method uses a raw query to give the row count.
  Future<int?> queryRowCount() async {
    Database db = await instance.database;
    return Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM $table'));
  }

  // We are assuming here that the id column in the map is set. The other
  // column values will be used to update the row.
  Future<int> update(Map<String, dynamic> row) async {
    Database db = await instance.database;
    var id = row[columnid];
    return await db.update(table, row, where: '$columnid = ?', whereArgs: [id]);
  }

  Future<int> updateOnly(String id, String type, String value) async {
    Database db = await instance.database;
    //var id = row[columnid];

    if (type=='event')
      {
        return await db.rawUpdate('''
    UPDATE user_info 
    SET type = ? 
    WHERE id = ?
    ''',
            [value,id]);
        print ('gercekten burdayim');
      }
    else if (type=='rain')
      {
    return await db.rawUpdate('''
    UPDATE user_info 
    SET rain = ? 
    WHERE id = ?
    ''',
    [value,id]);
        print ('gercekten degilim');
      }
    else if (type=='wet')
      {
        return await db.rawUpdate('''
    UPDATE user_info 
    SET wet = ? 
    WHERE id = ?
    ''',
            [value,id]);
      }
    else if (type=='casualty')
    {
      return await db.rawUpdate('''
    UPDATE user_info 
    SET casualty = ? 
    WHERE id = ?
    ''',
          [value,id]);
    }
    else if (type=='comments')
    {
      return await db.rawUpdate('''
    UPDATE user_info 
    SET comments = ? 
    WHERE id = ?
    ''',
          [value,id]);
    }
    else if (type=='concent')
    {
      return await db.rawUpdate('''
    UPDATE user_info 
    SET name = ? 
    WHERE id = ?
    ''',
          [value,id]);
    }
    else
      {
        return -1;
      }
    /*
    return await db.rawUpdate('''
    UPDATE user_info 
    SET type = ?
    WHERE id = ?
    ''',
        [value,id]);

     */

    //return await db.update(table, row, where: '$columnid = ?', whereArgs: [id]);
  }

  // Deletes the row specified by the id. The number of affected rows is
  // returned. This should be 1 as long as the row exists.
  Future<int> delete(int id) async {
    Database db = await instance.database;
    return await db.delete(table, where: '$columnid = ?', whereArgs: [id]);
  }
}


/*

import 'package:path/path.dart' as Path;
import 'model.dart';
import 'package:sqflite/sqflite.dart';
late Database _database;

Future openDb() async {
  _database = await openDatabase(Path.join(await getDatabasesPath(), "ss.db"),
      version: 1, onCreate: (Database db, int version) async {
        await db.execute(
          "CREATE TABLE model(id INTEGER PRIMARY KEY autoincrement, fruitName TEXT, quantity TEXT)",
        );
      });
  return _database;
}

Future XopenDb() async {
  _database = await openDatabase(Path.join(await getDatabasesPath(), "ageo.db"),
      version: 1, onCreate: (Database db, int version) async {
        await db.execute(
          "CREATE TABLE user_info(id TEXT PRIMARY KEY,name TEXT,longitude TEXT,latitude TEXT,altitude TEXT,time TEXT,type TEXT,rain TEXT,wet TEXT,casualty TEXT,comments TEXT,cHeading TEXT,cAccuracy TEXT,aX TEXT,aY TEXT,aZ TEXT,gX TEXT,gY TEXT,gZ TEXT,mX TEXT,mY TEXT,mZ TEXT,pOrient TEXT)",
        );
      });
  return _database;
}

Future insertModel(Model model) async {
  await openDb();
  return await _database.insert('model', model.toJson());
}

Future<List<Model>> getModelList() async {
  await openDb();
  final List<Map<String, dynamic>> maps = await _database.query('model');

  return List.generate(maps.length, (i) {
    return Model(
        id: maps[i]['id'],
        fruitName: maps[i]['fruitName'],
        quantity: maps[i]['quantity']);
  });
  // return maps
  //     .map((e) => Model(
  //         id: e["id"], fruitName: e["fruitName"], quantity: e["quantity"]))
  //     .toList();
}

Future<int> updateModel(Model model) async {
  await openDb();
  return await _database.update('model', model.toJson(),
      where: "id = ?", whereArgs: [model.id]);
}

Future<void> deleteModel(Model model) async {
  await openDb();
  await _database.delete('model', where: "id = ?", whereArgs: [model.id]);
}

 */
