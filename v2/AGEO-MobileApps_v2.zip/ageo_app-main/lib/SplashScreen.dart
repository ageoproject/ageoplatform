import 'dart:async';

import 'package:flutter/material.dart';

import 'FirstSceen.dart';

class SplashScreen extends StatefulWidget {
  final Color backgroundColor = Colors.white;
  final TextStyle styleTextUnderTheLoader = TextStyle(
      fontSize: 18.0, fontWeight: FontWeight.bold, color: Colors.black);

  @override
  _SplashScreenState createState() => _SplashScreenState();


}

class _SplashScreenState extends State<SplashScreen> {

  //String _versionName = 'V 4.9.3';
  String _versionName = 'V 5.0.0';
  //String _versionName = 'V 5.0.1';
  final splashDelay = 5;

  @override
  void initState() {
    super.initState();

    _loadWidget();

  }

  _loadWidget() async {
    var _duration = Duration(seconds: splashDelay);
    return Timer(_duration, navigationPage);
  }

  void navigationPage() {
    //Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => AfterSplash()));
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => FirstScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:

      InkWell(
        child:
        Stack(
          fit: StackFit.expand,
          children: <Widget>[
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 7,
                  child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[

                          Image.asset(
                            'images/ageo_transparent2.png',
                            //'images/ageo_pro_transparent2.png',
                            height: 150,
                            width: 300,
                          ),

                          /*
                    Image.network(
                        'https://ageoatlantic.eu/wp-content/uploads/2019/06/AGEO-transparent.png'),

                         */
                          Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                          ),
                        ],
                      )),
                ),
                Expanded(
                  child: //Column(
                    //children: <Widget>[
                      //CircularProgressIndicator(),
                      //Container(
                      //  height: 10,
                      //),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            Spacer(),
                            Text(_versionName),
                            Spacer(
                              flex: 2,
                            ),
                            CircularProgressIndicator(),
                            Spacer(
                              flex: 2,
                            ),
                            Text('AGEO'),
                            Spacer(),
                          //])
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),//),
    );
  }
}