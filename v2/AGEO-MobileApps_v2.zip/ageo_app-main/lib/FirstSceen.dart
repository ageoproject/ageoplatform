// ignore: file_names
// ignore: file_names
// ignore: file_names
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'ageo_db_helper.dart';
import 'package:flutter/foundation.dart' show kIsWeb;


//import 'package:path_provider/path_provider.dart';
//import 'package:path/path.dart' as Path;




@override

/*
class FirstScreen extends StatefulWidget {


  _FirstScreenState createState() => _FirstScreenState();
//Home(this.appDocPath);
}

class _FirstScreenState extends State<FirstScreen> {

 */


class FirstScreen extends StatelessWidget {


  //final dbHelper2 = DatabaseHelper.instance;
  //final AGEO_usHelper = AGEO_UserHelper.instance;
  final AGEO_usHelper = AGEO_DatabaseHelper.instance;



  void _DBinsert(row) async {
    final id = await AGEO_usHelper.insert(row);
    print('inserted row id: $id');
  }
/*
  void _query() async {
    final allRows = await dbHelper2.queryAllRows();
    print('query all rows:');
    allRows.forEach(print);
  }

  void _DBquery() async {
    final allRows = await AGEO_dbHelper2.queryAllRows();
    print('query all rows:');
    allRows.forEach(print);
  }
*/

  void _DBupdate(id,type,value) async {
    // row to update

    final rowsAffected = await AGEO_usHelper.updateOnly(id,type,value);
    print('updated $rowsAffected row(s)');
  }

  Future<List<Map<String, dynamic>>> _DBSingleQuery(String id) async {
    //final allRows = await AGEO_dbHelper2.queryARow(id);
    List<Map<String, dynamic>> ARow = await AGEO_usHelper.queryARow(id);
    print('query a row:');
    ARow.forEach(print);
    return ARow;

  }


/*
class FirstScreen extends StatefulWidget {


  _FirstScreenState createState() => _FirstScreenState();
//Home(this.appDocPath);
}

class _FirstScreenState extends State<FirstScreen> {
*/
  //bool accOrnot = false;



  @override
  Widget build(BuildContext context) {

    return Scaffold(
      //backgroundColor:Colors.blueAccent,

      /*
      appBar: AppBar(
        title: Text('AGEO Menu'),
      ),

       */

      body:
      Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.blueAccent, Colors.white])
          ),

          child:Center(
            //alignment: Alignment.center,
            child:
            ListView(
              //mainAxisAlignment: MainAxisAlignment.center,
              //crossAxisAlignment: CrossAxisAlignment.center,
              // Important: Remove any padding from the ListView.
              //padding: EdgeInsets.zero,
              shrinkWrap: true,
              padding: const EdgeInsets.all(20.0),

              children: <Widget>[
                Image.asset(
                  'images/ageo_transparent2.png',
                  height: 150,
                  width: 300,
                ),
                /*DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text('Drawer Header'),
            ),

             */
                Center(child:Card(

                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40), // if you need this
                    side: BorderSide(
                      color: Colors.grey.withOpacity(0.2),
                      width: 1,
                    ),),
                  //color: Colors.white,
                  color: Colors.pinkAccent,
                  child:
                  ListTile(
                    //title: Text('Report Incident',textAlign: TextAlign.center,
                    title: Text('Monitor Event',textAlign: TextAlign.center,
                    ),
                    //dense: true,
                    //subtitle: Text('Inform AGEO about geo-hazards',textAlign: TextAlign.center,style: new TextStyle(color: Colors.blue)),
                    //subtitle: Text('Inform AGEO about geo-hazards',textAlign: TextAlign.center,style: new TextStyle(color: Colors.white)),
                    subtitle: Text('Inform AGEO about geo-hazards and other incidents',textAlign: TextAlign.center,style: new TextStyle(color: Colors.white)),
                    trailing: Icon(Icons.keyboard_arrow_right),

                    onTap: ()
                    /*{
                      // Update the state of the app.
                      // ...
                      Navigator.pushNamed(context, '/select');
                      //Navigator.pop(context);
                    }*/

                    async {
                      // Update the state of the app.
                      // ...
                      //_listenLocation();
                      if ((MediaQuery.of(context).viewInsets.bottom == 0) == false)
                      {
                        print ('key?'+ MediaQuery.of(context).viewInsets.bottom.toString());
                        FocusManager.instance.primaryFocus?.unfocus();
                      }

                      late bool accOrnot = false;
                      var accOrnot_bool;
                      //_DBupdate('concent','concent','xx');
                      if (kIsWeb)
                        {
                          accOrnot = false;
                        }
                      else {
                         accOrnot_bool = await _DBSingleQuery('concent');
                      }

                      if (accOrnot_bool.isEmpty)
                      {
                        //setState(() {
                        accOrnot = false;
                        //});

                      }
                      else if (accOrnot_bool[0]['name'].toString()=='true') {
                        //setState(() {
                        accOrnot = true;
                        //});
                      }
                      else {
                        //setState(() {
                        accOrnot = false;
                        //});
                      }

                      //var accOrnot;

                      if (accOrnot==true)
                      {
                        print('Nedir1' + accOrnot.toString() );
                        Navigator.pushNamed(context, '/select');
                      }
                      else {
                        print('Nedir1' + accOrnot.toString() );
                        showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: Text('AGEO does not collect any sensitive personal information.'),
                                content: SingleChildScrollView(
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                          'The photos you captured and their related sensor data can be used by AGEO consortium for research purposes.'),
                                      Text(
                                          '\nWould you like to confirm this message?'),
                                    ],
                                  ),
                                ),
                                actions: <Widget>[
                                  TextButton(
                                    child: Text('Confirm'),
                                    onPressed: () async {
                                      print('Confirmed');
                                      //accOrnot=true;



                                      if (!accOrnot_bool.isEmpty)
                                      {
                                        _DBupdate('concent','concent','true');
                                      }
                                      else {
                                        Map<String, dynamic> consento = {
                                          AGEO_DatabaseHelper.columnid: 'concent',
                                          AGEO_DatabaseHelper.columnname: 'true',
                                        };

                                        _DBinsert(consento);
                                        //_DBupdate('concent','concent','xx');
                                      }
                                      print('Nedir 2' + accOrnot.toString() );
                                      await Geolocator.requestPermission();
                                      Navigator.pop(context);
                                      Navigator.pushNamed(context, '/select');
                                      //Navigator.of(context).pop();
                                    },
                                  ),
                                  TextButton(
                                    child: Text('Cancel'),
                                    onPressed: () {
                                      //accOrnot=false;
                                      print('Nedir 3' + accOrnot.toString() );
                                      Navigator.pop(context);

                                      //Navigator.pushNamed(context, '/first');

                                    },
                                  ),
                                ],
                              );
                            }
                        );
                      }


                      //Navigator.pushNamed(context, '/second');
                      //Navigator.pop(context);


                    },
                  ),),),

                Center(child:SizedBox(
                  width: MediaQuery.of(context).size.width/1.5,
                  //height: 300,
                  child:
                  Card(
                    color: Colors.white,
                    child:ListTile(
                      title: Text('About Us',textAlign: TextAlign.center),
                      //dense: true,
                      subtitle: Text('Information regarding the AGEO Project',textAlign: TextAlign.center,style: new TextStyle(color: Colors.blue)),
                      trailing: Icon(Icons.keyboard_arrow_right),
                      onTap: () {
                        // Update the state of the app.
                        // ...
                        if ((MediaQuery.of(context).viewInsets.bottom == 0) == false)
                        {
                          print ('key?'+ MediaQuery.of(context).viewInsets.bottom.toString());
                          FocusManager.instance.primaryFocus?.unfocus();
                        }

                        Navigator.pushNamed(context, '/about');
                        //Navigator.pop(context);


                      },
                    ),),),),
                Center(child:SizedBox(
                  width: MediaQuery.of(context).size.width/1.5,
                  //height: 300,
                  child:Card(
                    color: Colors.white,
                    child:ListTile(
                      title: Text('Partners',textAlign: TextAlign.center),
                      //dense: true,
                      subtitle: Text('Information regarding the AGEO Consortium',textAlign: TextAlign.center,style: new TextStyle(color: Colors.blue)),
                      trailing: Icon(Icons.keyboard_arrow_right),
                      onTap: () {
                        if ((MediaQuery.of(context).viewInsets.bottom == 0) == false)
                        {
                          print ('key?'+ MediaQuery.of(context).viewInsets.bottom.toString());
                          FocusManager.instance.primaryFocus?.unfocus();
                        }
                        // Update the state of the app.
                        // ...
                        Navigator.pushNamed(context, '/partners');
                        //Navigator.pop(context);


                      },
                    ),),),),

                Center(child:SizedBox(
                  width: MediaQuery.of(context).size.width/1.5,
                  //height: 300,
                  child:Card(
                    color: Colors.white,
                    child:ListTile(
                      title: Text('Contact Us',textAlign: TextAlign.center),
                      //dense: true,
                      subtitle: Text('Have a question? Please get in touch',textAlign: TextAlign.center,style: new TextStyle(color: Colors.blue)),
                      trailing: Icon(Icons.keyboard_arrow_right),
                      onTap: () {
                        if ((MediaQuery.of(context).viewInsets.bottom == 0) == false)
                        {
                          print ('key?'+ MediaQuery.of(context).viewInsets.bottom.toString());
                          FocusManager.instance.primaryFocus?.unfocus();
                        }
                        // Update the state of the app.
                        // ...
                        Navigator.pushNamed(context, '/contact');
                        //Navigator.pop(context);


                      },
                    ),),),),



              ],
            ),


          )),


/*
      body: Drawer(
        // Add a ListView to the drawer. This ensures the user can scroll
        // through the options in the drawer if there isn't enough vertical
        // space to fit everything.
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: <Widget>[
            /*DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text('Drawer Header'),
            ),

             */
            ListTile(
              title: Text('Report Incident'),
              onTap: () {
                // Update the state of the app.
                // ...
                Navigator.pushNamed(context, '/second');
                //Navigator.pop(context);


              },
            ),
            ListTile(
              title: Text('Contact Us'),
              onTap: () {
                // Update the state of the app.
                // ...
                Navigator.pushNamed(context, '/contact');
                //Navigator.pop(context);


              },
            ),
            ListTile(
              title: Text('About Us'),
              onTap: () {
                // Update the state of the app.
                // ...
                Navigator.pushNamed(context, '/about');
                //Navigator.pop(context);


              },
            ),
            ListTile(
              title: Text('Partners'),
              onTap: () {
                // Update the state of the app.
                // ...
                Navigator.pushNamed(context, '/partners');
                //Navigator.pop(context);


              },
            ),
          ],
        ),
      )

 */
    );
  }
}