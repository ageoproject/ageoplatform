// ignore: file_names
import 'package:ageo_upload_cross/Earthquake2.dart';
import 'package:ageo_upload_cross/EventSelector.dart';
import 'package:ageo_upload_cross/Landslide2.dart';
import 'package:ageo_upload_cross/Flood2.dart';
import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart' as pic;
//import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:geolocator/geolocator.dart';


import 'Building2.dart';
import 'CaptureScreen.dart';
import 'Sinkhole2.dart';
//import 'Earthquake2.dart';



/// Determine the current position of the device.
///
/// When the location services are not enabled or permissions
/// are denied the `Future` will return an error.
Future<Position> _determinePosition() async {
  bool serviceEnabled;
  LocationPermission permission;

  // Test if location services are enabled.
  serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    // Location services are not enabled don't continue
    // accessing the position and request users of the
    // App to enable the location services.
    permission = await Geolocator.requestPermission();
    return Future.error('Location services are disabled - asking for permission...');





  }

  permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      // Permissions are denied, next time you could try
      // requesting permissions again (this is also where
      // Android's shouldShowRequestPermissionRationale
      // returned true. According to Android guidelines
      // your App should show an explanatory UI now.
      //await Geolocator.openAppSettings();
      //await Geolocator.openLocationSettings();
      permission = await Geolocator.requestPermission();
      return Future.error('Location permissions are denied');
    }
  }

  if (permission == LocationPermission.deniedForever) {
    // Permissions are denied forever, handle appropriately.
    await Geolocator.openAppSettings();
    await Geolocator.openLocationSettings();
    return Future.error(
        'Location permissions are permanently denied, we cannot request permissions.');
  }

  // When we reach here, permissions are granted and we can
  // continue accessing the position of the device.
  return await Geolocator.getCurrentPosition();
}

/*
void main() => runApp(LocationDateScreen());

class LocationDateScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      title: 'Flutter DateTimePicker Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: LocationDateScreen2(),
      localizationsDelegates: [
        GlobalWidgetsLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: [Locale('en', 'US')], //, Locale('pt', 'BR')],
    );
  }
}
*/


class LocationDateScreen extends StatefulWidget{

  //final String event_type;
  //String event_type;
  //LocationDateScreen(this.event_type);
  //LocationDateScreen({required this.event_type}) : super();
  //LocationDateScreen({required this.event_type}) : super();
  //const LocationDateScreen({Key? key, required this.event_type}) : super(key: key);

  // Declare a field that holds the Todo.


  String evenType;
  LocationDateScreen({Key? key,required this.evenType}) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  HomePage createState()=> HomePage(this.evenType);
}



class HomePage extends State<LocationDateScreen>{
//late String event_type;
//HomePage(this.event_type);
String evenType;
HomePage(this.evenType);

bool visible = false;
bool visibleSens = false;
bool visibleSend = false;
bool visibleShare = false;


  //Your code here
//}

//class LocationDateScreen extends StatelessWidget {
  //class LocationDateScreen extends StatefulWidget {
  // This widget is the root of your application.

  bool isChecked = false;
  bool isChecked2 = false;
  bool isChecked3 = false;
  bool isChecked4 = false;


  GlobalKey<FormState> _oFormKey = GlobalKey<FormState>();
  late TextEditingController _controller1;
  late TextEditingController _controller2;
  late TextEditingController _controller3;
  late TextEditingController _controller4;

  //String _initialValue = '';
  String _valueChanged1 = '';
  String _valueToValidate1 = '';
  String _valueSaved1 = '';
  String _valueChanged2 = '';
  String _valueToValidate2 = '';
  String _valueSaved2 = '';
  String _valueChanged3 = '';
  String _valueToValidate3 = '';
  String _valueSaved3 = '';
  String _valueChanged4 = '';
  String _valueToValidate4 = '';
  String _valueSaved4 = '';

  //late double curLat = 33.33;
  //late double curLon = 33.33;
  late double curLat = 53.3498;
  late double curLon = -6.2603;
  late double curAlt = 5;
  late String dt='';
  late String rain = 'No';
  late String cas = 'No';

  //late String curAcc = '';

  final MapController myController = new MapController();

  //String get event_type => event_type;


  //late double curLat;
  //late double curLon;

  @override
  void initState() {
    super.initState();


    initializeDateFormatting();

    //Geolocator.requestPermission();
    //_determinePosition();
    _getLoca();

    Intl.defaultLocale = 'pt_BR';
    //_initialValue = DateTime.now().toString();
    _controller1 = TextEditingController(text: DateTime.now().toString());
    _controller2 = TextEditingController(text: DateTime.now().toString());
    _controller3 = TextEditingController(text: DateTime.now().toString());

    String lsHour = TimeOfDay.now().hour.toString().padLeft(2, '0');
    String lsMinute = TimeOfDay.now().minute.toString().padLeft(2, '0');
    _controller4 = TextEditingController(text: '$lsHour:$lsMinute');

    _getValue();
    //Position position = _determinePosition();
    //print (testingLoc.toString());

  }

  void _getLoca() async {
//    _determinePosition();

    //Future<Position> _determinePosition() async {
      bool serviceEnabled;
      LocationPermission permission;

      // Test if location services are enabled.
      serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        // Location services are not enabled don't continue
        // accessing the position and request users of the
        // App to enable the location services.
        permission = await Geolocator.requestPermission();
        //return Future.error('Location services are disabled - asking for permission...');
        }

      permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          // Permissions are denied, next time you could try
          // requesting permissions again (this is also where
          // Android's shouldShowRequestPermissionRationale
          // returned true. According to Android guidelines
          // your App should show an explanatory UI now.
          await Geolocator.openAppSettings();
          await Geolocator.openLocationSettings();
          permission = await Geolocator.requestPermission();
          //return Future.error('Location permissions are denied');
        }
      }

      if (permission == LocationPermission.deniedForever) {
        // Permissions are denied forever, handle appropriately.
        await Geolocator.openAppSettings();
        await Geolocator.openLocationSettings();
        //return Future.error(
        //    'Location permissions are permanently denied, we cannot request permissions.');
      }

      // When we reach here, permissions are granted and we can
      // continue accessing the position of the device.
      //return await Geolocator.getCurrentPosition();
    //}

    //await Geolocator.requestPermission();
    //await _determinePosition();

    //permission = ;
    if (await Geolocator.checkPermission() != LocationPermission.always || await Geolocator.checkPermission() != LocationPermission.whileInUse) {
      await Geolocator.requestPermission();
    }
//LocationPermission    permission = await Geolocator.requestPermission();

    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.best);
      print(position.latitude);
      print(position.longitude);
      print(position.latitude.toString() + " " + position.longitude.toString());
      print(position.altitude.toString() + " alt " + position.altitude.toString());

      curLat = position.latitude;
      curLon = position.longitude;
      curAlt = position.altitude;

      visibleSend = true;
      visible = true;
      visibleShare = false;

    } catch (e) {
      print('Location not shared');
      visibleShare = true;
      await Geolocator.requestPermission();
      //await _determinePosition();


      if (await Geolocator.checkPermission() == LocationPermission.deniedForever || await Geolocator.checkPermission() == LocationPermission.denied) {
        // Permissions are denied forever, handle appropriately.
        await Geolocator.openAppSettings();
        await Geolocator.openLocationSettings();
        visibleShare = true;
      }
    }


    setState(() {

    myController.move(pic.LatLng(curLat, curLon), 15);

    markers.add(
      Marker(
        width: 150.0,
        height: 150.0,
        point: pic.LatLng(curLat,curLon),
        builder: (ctx) => const Icon(
          Icons.location_on,
          color: Colors.red,
          size: 35.0,
        ),
      ),
    );
    });




    //return position;
  }
  /// This implementation is just to simulate a load data behavior
  /// from a data base sqlite or from a API
  Future<void> _getValue() async {

    await Future.delayed(const Duration(seconds: 3), () {
      setState(() {
        //_initialValue = '2000-10-22 14:30';
        _controller1.text = '2000-09-20 14:30';
        _controller2.text = '2001-10-21 15:31';
        _controller3.text = '2002-11-22';
        _controller4.text = '17:01';
        dt = DateTime.now().toUtc().toString();
        visibleSens = true;
        visible = true;

      });
    });
  }

  //burda baslar map
    List<Marker> markers = [];
  //String eventText='';
  String evenText='';

  // ignore: use_function_type_syntax_for_parameters



    Widget build(BuildContext context) {

      //ListTileControlAffinity.values.add('yes');
      //ListTileControlAffinity.values.add('no');

      if (evenType.compareTo('buildingsettlement')==0)
      {
        evenText='Building Settlement';
      }
      else
        {
          evenText = evenType.substring(0,1).toUpperCase()+evenType.substring(1,evenType.length);
        }
      //_getLoca();
      //_getLoca();
      //_getLoca();
      //_getLoca();
      //_getLoca();
      //_getLoca();
      Color getColor(Set<MaterialState> states) {
        const Set<MaterialState> interactiveStates = <MaterialState>{
          MaterialState.pressed,
          MaterialState.hovered,
          MaterialState.focused,
        };
        if (states.any(interactiveStates.contains)) {
          return Colors.blue;
        }
        return Colors.red;
      }


      _goBack(BuildContext context) {
        //Navigator.pop(context);
        //Navigator.pushNamed(context, '/select');
        Navigator.push(context,MaterialPageRoute(builder: (context) => EventSelector()));


      }

      double currentZoom = 15.0;
      //MapController mapController = MapController();
      pic.LatLng currentCenter = pic.LatLng(curLat, curLon);

      void _zoomout() {
        //currentZoom = myController.zoom - 1;
        myController.move(myController.center, myController.zoom - 1);
      }

      void _zoomin() {
        //currentZoom = myController.zoom + 1;
        myController.move(myController.center, myController.zoom + 1);
      }

    return
    Scaffold(
      appBar: AppBar(
        title: MediaQuery.of(context).size.width > 700 ? Text('Pick Location & Date for ' + evenText,): Text('Pick Location & Date for ' + evenText,style: TextStyle(fontSize: 15),),
          //title: MediaQuery.of(context).size.width > 700 ? Text('Capture Photo of ' + evenText,) :
        //title: Text('Pick Location & Date for ' + evenText + ' Event',style: TextStyle(fontSize: 15),),
        //title: Text('Location & Date Time Picker'),
        /*
        leading: IconButton(
          icon: Icon(Icons.arrow_back_rounded),
          iconSize: 20.0,
          onPressed: () {
            _goBack(context);
          },
        ),*/
      ),
      body:

          /*


                ListView(
                    shrinkWrap: true,
                    padding: EdgeInsets.all(15.0),
                    children: <Widget>[
           */
      Container(
        //width: MediaQuery.of(context).size.width * 0.5,
      decoration: BoxDecoration(
      gradient: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Colors.lightBlueAccent, Colors.white])
      ),

      child:
      //Center(
      //child:
      Column(children: <Widget>[
        Expanded(
        child:
        ListView(
        shrinkWrap: true,
        //padding: EdgeInsets.all(15.0),
        padding: EdgeInsets.only(left:MediaQuery.of(context).size.width * 0.07,right:MediaQuery.of(context).size.width * 0.07),
        //margin: EdgeInsets.only(left:MediaQuery.of(context).size.width * 0.07,right:MediaQuery.of(context).size.width * 0.07),
        children: <Widget>[

          //Divider(height: 1),
          Container(
      // here
      //height: BoxFit.fitHeight,

          height: MediaQuery.of(context).size.height * 0.4,
          //width: MediaQuery.of(context).size.width * 0.8,

      //var padding = MediaQuery.of(context).padding;
      //double newheight = MediaQuery.of(context).size.height - MediaQuery.of(context).padding.top - MediaQuery.of(context).padding.bottom;
      //MediaQuery.of(context).size.height,//100,
      alignment: Alignment.centerLeft,
      child:
      /*
      Column(
          children:  <Widget>[
          Text('Deliver features faster'),
    */

      /*
            myController.move(pic.LatLng(curLat, curLon), 15);
    markers.add(
      Marker(
        width: 150.0,
        height: 150.0,
        point: pic.LatLng(curLat,curLon),
        builder: (ctx) => const Icon(
          Icons.location_on,
          color: Colors.red,
          size: 35.0,
        ),
      ),
    );
       */

      FlutterMap(
        mapController:myController,
      options: MapOptions(

        center: pic.LatLng(curLat, curLon),
        zoom: 15.0,
        /*
        onTap: (tapPosition, point) => {
          print(point.toString()),
        },
        */
        onTap: (tapPosition,pic.LatLng point) {
            setState(() {
              curLat = point.latitude;
              curLon = point.longitude;
              curAlt  = 99.99;
              markers.removeLast();
              markers.add(
                Marker(
                  width: 150.0,
                  height: 150.0,
                  point: point,
                  builder: (ctx) => const Icon(
                    Icons.location_on,
                    color: Colors.red,
                    size: 35.0,
                  ),
                ),
              );
            });
          },
        /*
        onTap: (tapPosition,pic.LatLng point) {
          print('tapped');
          setState(() {
            marker.add(Marker(
              markerId: MarkerId(point.toString()),
              position: point,
              icon: BitmapDescriptor.defaultMarker,
            ));
          });
        },
        */
      ),

      layers: [

        new TileLayerOptions(
          urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
          subdomains: ['a', 'b', 'c']
          /*
          urlTemplate: "https://api.tiles.mapbox.com/v4/"
              "{id}/{z}/{x}/{y}@2x.png?access_token={accessToken}",
          additionalOptions: {
            'accessToken': '<PUT_ACCESS_TOKEN_HERE>',
            'id': 'mapbox.streets',
          },*/
        ),
        new MarkerLayerOptions(

            markers: [
              for (int i = 0; i < markers.length; i++) markers[i]
            ]
          /*markers: [
            new Marker(
              width: 80.0,
              height: 80.0,
              point: new pic.LatLng(51.5, -0.09),
              builder: (ctx) =>
              new Container(
                child: new FlutterLogo(),
              ),
            ),
          ],
          */
        ),

      ],),
        ),
          Center(child:
          Row (

            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Center(child:
              //Text('tap on map to\t \nchange pin location\t ', textAlign: TextAlign.right, ),
              Text('tap on map to\n\t\t\tchange pin location\t\t\t', textAlign: TextAlign.center,),
              ),
              //Spacer(flex:1),
              FloatingActionButton(
                heroTag: "btn1",
                onPressed: _zoomout,
                tooltip: 'Zoom Out',
                child: Icon(Icons.remove_circle_outline_rounded),
              ),
              FloatingActionButton(
                heroTag: "btn2",
                onPressed: _zoomin,
                tooltip: 'Zoom In',
                child: Icon(Icons.add_circle_outline_rounded),
              ),
            ],),
          ),


        Container(
          // here
          //height: BoxFit.fitHeight,
          //height: MediaQuery.of(context).size.height * 0.4,
          width: MediaQuery.of(context).size.width * 0.5,

          //var padding = MediaQuery.of(context).padding;
          //double newheight = MediaQuery.of(context).size.height - MediaQuery.of(context).padding.top - MediaQuery.of(context).padding.bottom;
          //MediaQuery.of(context).size.height,//100,
          alignment: Alignment.centerLeft,
          child:
          /*DateTimePicker(
            type: DateTimePickerType.dateTime,
            dateMask: 'd MMMM, yyyy - hh:mm a',
            //controller: _controller2,
            //initialValue: _initialValue,
            initialValue: DateTime.now().toString(),
            firstDate: DateTime(2000),
            lastDate: DateTime(2100),
            icon: Icon(Icons.event),
            dateLabelText: 'Date Time',
            use24HourFormat: false,
            //locale: Locale('en', 'US'),

            onChanged: (val) => print(val),
            validator: (val) {
              print(val);
              return null;
            },
            onSaved: (val) => print(val),
          ),*/

            //onChanged: (val) => setState(() => _valueChanged2 = val),
            //validator: (val) {
            //  setState(() => _valueToValidate2 = val ?? '');
            //  return null;
            //},
            //onSaved: (val) => setState(() => _valueSaved2 = val ?? ''),
          //),
          DateTimePicker(
        //type: DateTimePickerType.dateTimeSeparate,
        type: DateTimePickerType.dateTime,
        //dateMask: 'd MMM, yyyy',
        //dateMask: 'd MMMM, yyyy - hh:mm a',
            dateMask: 'd MMMM, yyyy - HH:mm',
        initialValue: DateTime.now().toString(),
        firstDate: DateTime(2000),
        lastDate: DateTime.now(),
        icon: Icon(Icons.calendar_today),
        dateLabelText: 'Date Time',
        //timeLabelText: "Hour",
        //use24HourFormat: false,
        locale: Locale('en', 'US'),

            /*selectableDayPredicate: (date) {
          // Disable weekend days to select from the calendar
          if (date.weekday == 6 || date.weekday == 7) {
            return false;
          }

          return true;
        },*/
        //onChanged: (val) => print(val),
        onChanged: (val) {print(val); setState(() {
          dt = DateTime.parse(val).toUtc().toString();
          print ('val: '+val.substring(0,val.length-3));
          print('now');
          print(DateTime.now().toString().substring(0,DateTime.now().toString().length-13));

          String testor1=val.substring(0,val.length-3);
          String testor2=DateTime.now().toString().substring(0,DateTime.now().toString().length-13);
          if (testor1.compareTo(testor2) == 0) {
            //isChecked = false;
          }
          else
            {
              

              /*
              print(DateTime.now());
              print('datenowst: '+DateTime.now().toString());
              print('utc');
              print(DateTime.now().toUtc());
              print('parse');
              print(DateTime.parse(val));
              
              print ('sik'+DateTime.now().difference(DateTime.parse(val).));
                //..compareTo(DateTime.parse(val)));
               */
            //isChecked=true;
          }
        }); },
        validator: (val) {
          print(val);
          return null;
        },
        onSaved: (val) => print(val),
      ),
        ),
      /*
      DateTimePicker(
        initialValue: '',
        firstDate: DateTime(2000),
        lastDate: DateTime(2100),
        dateLabelText: 'Date',
        onChanged: (val) => print(val),
        validator: (val) {
          print(val);
          return null;
        },
        onSaved: (val) => print(val),
      ),
        */
          /*Checkbox(
            checkColor: Colors.white,
            fillColor: MaterialStateProperty.resolveWith(getColor),

            value: isChecked,
            onChanged: (bool? value) {
              setState(() {
                isChecked = value!;
              });
            },
          ),*/


        //Divider(height: 10),
        Container(
          width: MediaQuery.of(context).size.width * 0.4,
          alignment: Alignment.centerLeft,
          child:CheckboxListTile(
            //controlAffinity: ListTileControlAffinity.values,
            //secondary: const Icon(Icons.alarm),
          //title: const Text('Experienced the event on this date'),
            title: const Text('Is / was it raining ?'),
          //subtitle: Text('Select if it was/is raining during the event'),
          value: isChecked,
          onChanged: (bool? value) {
            setState(() {
              isChecked = value!;
            });
          },
        ),),
        //Divider(height: 10),
        //Divider(height: 10),
        Container(
          width: MediaQuery.of(context).size.width * 0.4,
          alignment: Alignment.centerLeft,
          child:CheckboxListTile(
          //secondary: const Icon(Icons.alarm),
          title: const Text('People at risk ?'),
          //subtitle: Text('Select if there are people at risk'),
          value: isChecked2,
          onChanged: (bool? value) {
            setState(() {
              isChecked2 = value!;
            });
          },
        ),),
        //Divider(height: 10),
        //Divider(height: 10),
          Container(
            width: MediaQuery.of(context).size.width * 0.4,
            alignment: Alignment.centerLeft,
            child:CheckboxListTile(
          //secondary: const Icon(Icons.alarm),
          title: const Text('Animals at risk ?'),
              //subtitle: Text('Select if there are animals at risk'),
          value: isChecked3,
          onChanged: (bool? value) {
            setState(() {
              isChecked3 = value!;
            });
          },
        ),),
        //Divider(height: 10),
        //Divider(height: 10),
      Container(
      width: MediaQuery.of(context).size.width * 0.4,
      alignment: Alignment.centerLeft,
      child:CheckboxListTile(
          //secondary: const Icon(Icons.alarm),
          title: const Text('Assets at risk ?'),
          //subtitle: Text('Ringing after 12 hours'),
          //subtitle: Text('Select if there are any buildings or other assets at risk'),
          value: isChecked4,
          onChanged: (bool? value) {
            setState(() {
              isChecked4 = value!;
            });
          },
        ),),
        /*
        Container(
          width: MediaQuery.of(context).size.width * 0.8,
          alignment: Alignment.centerLeft,
          child:CheckboxListTile(
            //secondary: const Icon(Icons.alarm),
            title: const Text('Raining'),
            //subtitle: Text('Ringing after 12 hours'),
            value: isChecked4,
            onChanged: (bool? value) {
              setState(() {
                isChecked4 = value!;
              });
            },
          ),),
         */
        //Divider(height: 10),


        //]),),
        //Divider(height:100)
          /*
          SizedBox(
            height: 200,
            child: Text('')//<-- SEE HERE
          ),

           */


        /*
        RaisedButton(
          onPressed: () {
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,)));
          },
          color: Colors.green,
          textColor: Colors.white,
          padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
          child: Text('NEXT', style: TextStyle(fontSize: 20),),
          //child: Text('Click Here To Submit Data To Server'),
        ),

         */

      //Divider(height: 15,)
        ],
      ),),
        Visibility(
            visible: visibleShare,
            child:
            Center(child:Column(children: [Text('Location is not shared yet, please give permission.'), ElevatedButton(onPressed: (){_getLoca();}, child: Text('Request Permission'))],))
        ),
        Visibility(
            visible: !visibleSend,
            child:
            Center(child:Text('GPS waiting for satellites...'))
        ),
        Visibility(
            visible: !visibleSens,
            child:
            Center(child:Text('Aquiring current date and time...'))
        ),
        //Divider(height: 12),
        //Divider(height: 12),
        Visibility(
            visible: !visibleSend || !visibleSens,
            child: Center(
              //margin: EdgeInsets.only(bottom: 30),
                child: CircularProgressIndicator()
            )
        ),

        Visibility(
          visible: visibleSens && visibleSend && visible,
          child:
          Align(
            alignment: Alignment.bottomCenter,
            child:
            Column(children:[
              //Divider(height: 15,thickness: 0,),
              ElevatedButton(
                child: Text(
                    "     NEXT     ".toUpperCase(),
                    style: TextStyle(fontSize: 20)
                ),
                style: ButtonStyle(
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.teal),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          //borderRadius: BorderRadius.zero,
                            borderRadius: BorderRadius.circular(18.0),
                            side: BorderSide(color: Colors.teal)
                        )
                    )
                ), onPressed: () {
                //Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
                if (isChecked){rain='Yes';}else{rain='No';}
                if (isChecked2){cas='Yes';}else{cas='No';}
                if (evenType.compareTo('landslide')==0) {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Landslide2(
                          evenType: evenType,
                          curLat: curLat,
                          curLon: curLon,
                          curAlt: curAlt,
                          dt: dt,
                          rain: rain,
                          cas: cas)));
                }
                else if (evenType.compareTo('flood')==0) {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Flood2(
                          evenType: evenType,
                          curLat: curLat,
                          curLon: curLon,
                          curAlt: curAlt,
                          dt: dt,
                          rain: rain,
                          cas: cas)));
                }
                else if (evenType.compareTo('buildingsettlement')==0) {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Building2(
                          evenType: evenType,
                          curLat: curLat,
                          curLon: curLon,
                          curAlt: curAlt,
                          dt: dt,
                          rain: rain,
                          cas: cas)));
                }
                else if (evenType.compareTo('sinkhole')==0) {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Sinkhole2(
                          evenType: evenType,
                          curLat: curLat,
                          curLon: curLon,
                          curAlt: curAlt,
                          dt: dt,
                          rain: rain,
                          cas: cas)));
                }
                else if (evenType.compareTo('earthquake')==0) {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => Earthquake2(
                          evenType: evenType,
                          curLat: curLat,
                          curLon: curLon,
                          curAlt: curAlt,
                          dt: dt,
                          rain: rain,
                          cas: cas)));
                }

                else {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => CaptureScreen(
                          evenType: evenType,
                          curLat: curLat,
                          curLon: curLon,
                          curAlt: curAlt,
                          dt: dt,
                          rain: rain,
                          cas: cas)));
                }
              },
                //onPressed: () => null
              ),
              Divider(height: 15,thickness: 0,),
            ]),),

          /*
        FlatButton(
          color: Colors.teal,
          textColor: Colors.white,
          padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
          onPressed: () {
            if (isChecked){rain='Yes';}else{rain='No';}
            if (isChecked2){cas='Yes';}else{cas='No';}
            if (evenType.compareTo('landslide')==0) {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => Landslide2(
                      evenType: evenType,
                      curLat: curLat,
                      curLon: curLon,
                      curAlt: curAlt,
                      dt: dt,
                      rain: rain,
                      cas: cas)));
            }
            else if (evenType.compareTo('flood')==0) {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => Flood2(
                      evenType: evenType,
                      curLat: curLat,
                      curLon: curLon,
                      curAlt: curAlt,
                      dt: dt,
                      rain: rain,
                      cas: cas)));
            }
            else if (evenType.compareTo('buildingsettlement')==0) {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => Building2(
                      evenType: evenType,
                      curLat: curLat,
                      curLon: curLon,
                      curAlt: curAlt,
                      dt: dt,
                      rain: rain,
                      cas: cas)));
            }
            else if (evenType.compareTo('sinkhole')==0) {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => Sinkhole2(
                      evenType: evenType,
                      curLat: curLat,
                      curLon: curLon,
                      curAlt: curAlt,
                      dt: dt,
                      rain: rain,
                      cas: cas)));
            }
            else if (evenType.compareTo('earthquake')==0) {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => Earthquake2(
                      evenType: evenType,
                      curLat: curLat,
                      curLon: curLon,
                      curAlt: curAlt,
                      dt: dt,
                      rain: rain,
                      cas: cas)));
            }

            else {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => CaptureScreen(
                      evenType: evenType,
                      curLat: curLat,
                      curLon: curLon,
                      curAlt: curAlt,
                      dt: dt,
                      rain: rain,
                      cas: cas)));
            }
          },
          child: Text('NEXT', style: TextStyle(fontSize: 20),),
        ),*/
        ),
        //Divider(height: 25,thickness: 0,),
        ]
      ),
      ),
    );

  }
}

