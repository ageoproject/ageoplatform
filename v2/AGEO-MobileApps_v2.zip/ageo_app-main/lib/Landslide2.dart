import 'package:flutter/material.dart';

import 'CaptureScreen.dart';
import 'LocationDate.dart';

class Landslide2 extends StatefulWidget {

  String evenType;
  double curLat;
  double curLon;
  double curAlt;
  String dt;
  String rain;
  String cas;

  Landslide2({Key? key,required this.evenType, required this.curLat, required this.curLon, required this.curAlt, required this.dt, required this.rain, required this.cas}) : super(key: key);



  @override
  _SingleImageUploadState createState() {
    return _SingleImageUploadState(this.evenType,this.curLat,this.curLon,this.curAlt, this.dt, this.rain, this.cas);
  }
}

class _SingleImageUploadState extends State<Landslide2> {

//class Landslide2 extends StatelessWidget {

  bool isChecked1 = false;
  bool isChecked2 = false;
  bool isChecked3 = false;
  bool isChecked4 = false;
  bool isChecked5 = false;


  String evenType;
  double curLat;
  double curLon;
  double curAlt;
  String dt;
  String rain;
  String cas;

  double _currentSliderValue = 1.0;
  String gerzek = '';
  bool visik = false;

  _SingleImageUploadState(this.evenType,this.curLat,this.curLon,this.curAlt, this.dt, this.rain, this.cas);


  @override
  Widget build(BuildContext context) {

    return Scaffold(
        appBar: AppBar(
          title: Text('Observed Damage'),
          //title: Text('Landslides - Observed Damage'),
        ),


        body:
        Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.lightBlueAccent, Colors.white])
            ),

            child:
            Column(
                children: [

                  Row (
                    mainAxisAlignment: MainAxisAlignment.center,

                    children: [


                      Container(

                        //width: MediaQuery.of(context).size.width,
                        //crossAxisAlignment: CrossAxisAlignment.stretch
                        width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.2 : MediaQuery.of(context).size.width*0.20,
                        height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.20 : MediaQuery.of(context).size.height*0.20,
                        //MediaQuery.of(context).size.width > 700 ? 4 : 2
                        //color: Colors.blue,
                        //padding: const EdgeInsets.all(5.0),
                        alignment: Alignment.center,
                        //alignment: Alignment.bottomCenter,
                        //alignment: Alignment.center, // This is needed


                        child:


                        Align(

                          alignment: Alignment.center,
                          child:
                          //Text('Water Level',style: TextStyle(fontSize: 20,color: Colors.teal,),textAlign: TextAlign.left,),
                          Text('Volume of Displaced Land:',style: TextStyle(fontSize: 15,color: Colors.white, fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
                        ),
                      ),


                      Container(

                        //width: MediaQuery.of(context).size.width,
                        //crossAxisAlignment: CrossAxisAlignment.stretch
                          width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.8 : MediaQuery.of(context).size.width*0.8,
                          height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.20 : MediaQuery.of(context).size.height*0.20,
                          //MediaQuery.of(context).size.width > 700 ? 4 : 2
                          //color: Colors.blue,
                          padding: const EdgeInsets.all(0.0),
                          //alignment: Alignment.bottomCenter,
                          //alignment: Alignment.center, // This is needed


                          child:
                          Column(
                            //Stack(
                            //Container(height: MediaQuery.of(context).size.height*0.25,child:
                            //Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            //alignment: Alignment.bottomCenter,
                              children: <Widget>[
                                /*
    Container(
      width: 100,
      height: 100,
      color: Colors.red,
    ),
    Container(
      width: 90,
      height: 90,
      color: Colors.green,
    ),
    Container(
      width: 80,
      height: 80,
      color: Colors.blue,
    ),
     */
                                //Container(

                                //width: MediaQuery.of(context).size.width,
                                //crossAxisAlignment: CrossAxisAlignment.stretch
                                //height: MediaQuery.of(context).size.height*0.20,
                                //width: MediaQuery.of(context).size.width*0.5,
                                //color: Colors.blue,
                                //padding: const EdgeInsets.all(5.0),
                                //alignment: Alignment.topCenter,
                                //alignment: Alignment.bottomCenter,
                                //alignment: Alignment.center, // This is needed


                                //child: Image.asset("images/events/flood/waterlevel.png",fit: BoxFit.contain, width: MediaQuery.of(context).size.width, ),
                                //child:
                                //Image.asset("images/events/flood/waterlevel.png", ),
                                //Image.asset("images/events/flood/waterlevelW.png", width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.55 : MediaQuery.of(context).size.width*0.75,
                                //height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.21 : MediaQuery.of(context).size.height*0.07,),
                                /*
                      Image.asset("images/events/flood/waterlevelW.png", width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.45 : MediaQuery.of(context).size.width*0.85,
                      height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.21 : MediaQuery.of(context).size.height*0.11,),
                       */

                                Image.asset("images/events/landslide/volumeW2.png",width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.65 : MediaQuery.of(context).size.width*0.8,
                                    height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.15 : MediaQuery.of(context).size.height*0.08,
                                    fit:  MediaQuery.of(context).size.width > 700 ? BoxFit.fill : BoxFit.scaleDown),

/*
                                    Image.asset(
                                        "images/events/landslide/volumeW2.png",
                                        width: MediaQuery
                                            .of(context)
                                            .size
                                            .width > 700 ? MediaQuery
                                            .of(context)
                                            .size
                                            .width * 0.65 : MediaQuery
                                            .of(context)
                                            .size
                                            .width * 0.8,
                                        height: MediaQuery
                                            .of(context)
                                            .size
                                            .width > 700 ? MediaQuery
                                            .of(context)
                                            .size
                                            .height * 0.15 : MediaQuery
                                            .of(context)
                                            .size
                                            .height * 0.15,
                                        fit: BoxFit.fill),
 */



                                //Image.asset("images/partners/p1.png"),
                                //),




                                //Image.asset("images/events/flood/waterlevel.png", width: MediaQuery.of(context).size.width, ),

                                Container(

                                  width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.65 : MediaQuery.of(context).size.width*0.8,
                                  height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.05 : MediaQuery.of(context).size.height*0.05,
                                  //MediaQuery.of(context).size.width > 700 ? 4 : 2
                                  //color: Colors.blue,
                                  padding: const EdgeInsets.all(0.0),
                                  //width: MediaQuery.of(context).size.width,
                                  //crossAxisAlignment: CrossAxisAlignment.stretch
                                  //height: MediaQuery.of(context).size.height/4,
                                  //height: MediaQuery.of(context).size.height*0.05,
                                  //width: MediaQuery.of(context).size.width*0.5,
                                  //color: Colors.blue,
                                  //height: double.infinity,
                                  //padding: const EdgeInsets.all(5.0),
                                  //alignment: Alignment.bottomCenter,
                                  //alignment: Alignment.center, // This is needed


                                  child:
                                  SliderTheme(
                                    data: SliderTheme.of(context).copyWith(
                                      activeTrackColor: Colors.red[700],
                                      inactiveTrackColor: Colors.red[100],
                                      trackShape: RoundedRectSliderTrackShape(),
                                      //trackShape: CustomTrackShape(),

                            trackHeight: 4.0,
                            thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12.0),
                            //thumbColor: Colors.redAccent,
                            //overlayColor: Colors.red.withAlpha(32),
                            overlayShape: RoundSliderOverlayShape(overlayRadius: 28.0),
                            tickMarkShape: RoundSliderTickMarkShape(),
                            //activeTickMarkColor: Colors.red[700],
                            //inactiveTickMarkColor: Colors.red[100],
                            valueIndicatorShape: PaddleSliderValueIndicatorShape(),
                            //valueIndicatorColor: Colors.redAccent,


                                      valueIndicatorTextStyle: TextStyle(
                                        color: Colors.teal,
                                      ),
                                    ),
                                    child:Slider(
                                      activeColor: Colors.tealAccent,
                                      inactiveColor: Colors.teal,
                                      thumbColor: Colors.tealAccent,
                                      mouseCursor: MouseCursor.defer,
                                      autofocus : true,
                                      value: _currentSliderValue,
                                      min: 1.0,
                                      max: 6.0,
                                      divisions:4,
                                      //label: (_currentSliderValue>15) ? '>15.0 mm' : (_currentSliderValue<0.3) ? '<0.3 mm' : '<'+_currentSliderValue.toStringAsFixed(1)+' mm',
                                      //label: (_currentSliderValue==15) ? '>'+_currentSliderValue.round().toString() : '<'+_currentSliderValue.round().toString(),

                                      /*
              onChangeStart: (double value) {
                print('Start value is ' + value.toString());
              },

               */

                                      onChangeEnd: (double value) {
                                        if (value>15)
                                        {
                                          setState(() {
                                            //gerzek = '>'+value.round().toString() +' millimeters selected.';
                                            gerzek = '>15.0 millimeters selected.';
                                            //gerzek = '>'+value.toStringAsFixed(1) +' millimeters selected.';
                                          });
                                          print(value.round().toString() +' step.' );

                                        }

                                        else if (value<0.3)
                                        {
                                          setState(() {
                                            //gerzek = value.round().toString() +'+ steps selected.';
                                            gerzek = '<0.3 millimeters selected.';
                                          });

                                        }
                                        else {
                                          setState(() {
                                            gerzek = '<'+value.toStringAsFixed(1) +' millimeters selected.';
                                          });

                                          print(value.round().toString() +' steps.' );
                                        }
                                      },


                                      onChanged: (double value) {
                                        setState(() {
                                          _currentSliderValue = value;
                                        });
                                      },
                                    ),),
                                ),
                              ])
                        //),
                      ),
                    ],),



/*

            Container(
            //width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.55 : MediaQuery.of(context).size.width*0.75,
              width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.21 : MediaQuery.of(context).size.height*0.17,


            child:
                  Row (
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                  Align(
                    alignment: Alignment.center,
                    child:
                    MediaQuery.of(context).size.width < 700 ?
                    Text('Volume of \nDisplaced \nLand: ',style: TextStyle(fontSize: 15,color: Colors.white,),/*textAlign: TextAlign.left,*/):
                    //Text('Volume of Displaced Land',style: TextStyle(fontSize: 20,color: Colors.teal,),textAlign: TextAlign.left,),
                    Text('Volume of\nDisplaced Land:  ',style: TextStyle(fontSize: 20,color: Colors.white,),/*textAlign: TextAlign.left,*/),
                    //Text('Vol:',style: TextStyle(fontSize: 20,color: Colors.white,),textAlign: TextAlign.left,),
                  ),

            /*Container(
                //padding: EdgeInsets.all(0),
              //width: MediaQuery.of(context).size.width,
              //crossAxisAlignment: CrossAxisAlignment.stretch
              width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.55 : MediaQuery.of(context).size.width*0.75,
              height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.21 : MediaQuery.of(context).size.height*0.17,
              //MediaQuery.of(context).size.width > 700 ? 4 : 2
                //color: Colors.blue,
                //padding: const EdgeInsets.all(0.0),
              //alignment: Alignment.bottomCenter,
                //alignment: Alignment.center, // This is needed


                child:

             */
                  //Stack(
          Column(
                    //alignment: Alignment.bottomCenter,
                    children: <Widget>[
                      /*
    Container(
      width: 100,
      height: 100,
      color: Colors.red,
    ),
    Container(
      width: 90,
      height: 90,
      color: Colors.green,
    ),
    Container(
      width: 80,
      height: 80,
      color: Colors.blue,
    ),
     */
                      Container(
                        //padding: EdgeInsets.all(0),
                        //width: MediaQuery.of(context).size.width,
                        //crossAxisAlignment: CrossAxisAlignment.stretch
                        height: MediaQuery.of(context).size.height*0.08,
                        //width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.55 : MediaQuery.of(context).size.width*0.75,
                        width: MediaQuery.of(context).size.width*0.60,
                        //color: Colors.blue,
                        //padding: const EdgeInsets.all(5.0),
                        //alignment: Alignment.bottomCenter,
                        //alignment: Alignment.center, // This is needed


                        //child: Image.asset("images/events/landslide/volumeW.png",fit: BoxFit.contain, width: MediaQuery.of(context).size.width, ),
                        //child: Image.asset("images/events/landslide/volumeW.png",fit: BoxFit.contain,),
                        /*
                        child:
                        MediaQuery.of(context).size.width > 700 ? Image.asset("images/events/landslide/volumeW.png",fit: BoxFit.fill,) :
                        Image.asset("images/events/landslide/volumeW.png", width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.55 : MediaQuery.of(context).size.width*0.75,
                          height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.21 : MediaQuery.of(context).size.height*0.07,),

                         */

                        child: MediaQuery.of(context).size.width > 700 ?
                        Image.asset("images/events/landslide/volumeW.png",fit:  BoxFit.fill ): Image.asset("images/events/landslide/volumeW.png"),
                        //Image.asset("images/events/landslide/volumeW.png", width: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.width*0.55 : MediaQuery.of(context).size.width*0.75,
                          //height: MediaQuery.of(context).size.width > 700 ? MediaQuery.of(context).size.height*0.21 : MediaQuery.of(context).size.height*0.07,),


                        //Image.asset("images/partners/p1.png"),
                      ),




                      //Image.asset("images/events/flood/waterlevel.png", width: MediaQuery.of(context).size.width, ),

                      //Container(

                        //width: MediaQuery.of(context).size.width,
                        //crossAxisAlignment: CrossAxisAlignment.stretch
                        //height: MediaQuery.of(context).size.height/4,
                        //width: MediaQuery.of(context).size.width*0.75,
                        //color: Colors.blue,
                        //height: double.infinity,
                        //padding: const EdgeInsets.all(5.0),
                        //alignment: Alignment.topCenter,
                        //alignment: Alignment.center, // This is needed


                        //child:
                        SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            //activeTrackColor: Colors.red[700],
                            //inactiveTrackColor: Colors.red[100],
                            //trackShape: RoundedRectSliderTrackShape(),
                            trackShape: CustomTrackShape(),
                            /*
                            trackHeight: 4.0,
                            thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12.0),
                            //thumbColor: Colors.redAccent,
                            //overlayColor: Colors.red.withAlpha(32),
                            overlayShape: RoundSliderOverlayShape(overlayRadius: 28.0),
                            tickMarkShape: RoundSliderTickMarkShape(),
                            //activeTickMarkColor: Colors.red[700],
                            //inactiveTickMarkColor: Colors.red[100],
                            valueIndicatorShape: PaddleSliderValueIndicatorShape(),
                            //valueIndicatorColor: Colors.redAccent,

                             */
                            valueIndicatorTextStyle: TextStyle(
                              color: Colors.teal,
                            ),
                          ),
                          child:Slider(
                            activeColor: Colors.tealAccent,
                            inactiveColor: Colors.teal,
                            thumbColor: Colors.tealAccent,
                            mouseCursor: MouseCursor.defer,
                            autofocus : true,
                            value: _currentSliderValue,
                            min: 1.0,
                            max: 6.0,
                            divisions:4,
                            //label: (_currentSliderValue>15) ? '>15.0 mm' : (_currentSliderValue<0.3) ? '<0.3 mm' : '<'+_currentSliderValue.toStringAsFixed(1)+' mm',
                            //label: (_currentSliderValue==15) ? '>'+_currentSliderValue.round().toString() : '<'+_currentSliderValue.round().toString(),

                            /*
              onChangeStart: (double value) {
                print('Start value is ' + value.toString());
              },

               */

                            onChangeEnd: (double value) {
                              if (value>15)
                              {
                                setState(() {
                                  //gerzek = '>'+value.round().toString() +' millimeters selected.';
                                  gerzek = '>15.0 millimeters selected.';
                                  //gerzek = '>'+value.toStringAsFixed(1) +' millimeters selected.';
                                });
                                print(value.round().toString() +' step.' );

                              }

                              else if (value<0.3)
                              {
                                setState(() {
                                  //gerzek = value.round().toString() +'+ steps selected.';
                                  gerzek = '<0.3 millimeters selected.';
                                });

                              }
                              else {
                                setState(() {
                                  gerzek = '<'+value.toStringAsFixed(1) +' millimeters selected.';
                                });

                                print(value.round().toString() +' steps.' );
                              }
                            },


                            onChanged: (double value) {
                              setState(() {
                                _currentSliderValue = value;
                              });
                            },
                          ),),
                      //)
                    ],
                  ),
            //),
                  ],),),
            */

            Expanded(
            child:
            GridView.count(
                primary: false,
                padding: const EdgeInsets.all(5),

                crossAxisCount: MediaQuery.of(context).size.width > 700 ? 4 : 2,


                crossAxisSpacing: 20,
                mainAxisSpacing: 0.1,
                //crossAxisCount: 2,
                children: <Widget>[
                  //Text('Observed Damage',textAlign: TextAlign.left),
                  InkWell(
                    //onTap: () => launch('https://tecnico.ulisboa.pt/en/'),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => PartnersScreen())),
                    //onTap: () => Navigator.pop(context),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen())),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'landslide',))),
                    onTap: () {setState(() {
                      isChecked1=!isChecked1;;
                    });},//onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'landslide',))),
                    child:Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),

                        //Expanded(flex:2,child:Text("Landslide",textAlign: TextAlign.center,),),
                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Buildings',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked1,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked1 = value!;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/landslide/damage1.png"),),
                        //Expanded(child:Text("tecnico.ulisboa.pt/en",style: new TextStyle(color: Colors.blue)),),
                        //Text("https://tecnico.ulisboa.pt/en/"),

                      ],
                    ),),
                  InkWell(
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen())),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'rockslide',))),
                    onTap: () {setState(() {
                      isChecked2=!isChecked2;;
                    });},//onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'rockslide',))),
                    //onTap: () => launch('http://www.apgeologos.pt/'),
                    child:
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Green Area',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked2,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked2 = value!;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/landslide/damage2.png"),),
                        //Expanded(child:Text("www.apgeologos.pt",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),),
                  InkWell(
                    //onTap: () => launch('https://www.lapalmacentre.eu/'),
                    onTap: () {setState(() {
                      isChecked3=!isChecked3;
                    });},//onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'tsunami'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'tsunami',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.lapalmacentre.eu/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Road',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked3,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked3 = value!;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/landslide/damage3.png"),),
                        //Expanded(child:Text("www.lapalmacentre.eu",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),


                  InkWell(
                    //onTap: () => launch('https://www.igme.es/'),
                    onTap: () {setState(() {
                      isChecked4=!isChecked4;;
                    });},//=> Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'flood'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'flood'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'flood',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.igme.es/",style: new TextStyle(color: Colors.blue)),

                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Railway',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked4,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked4 = value!;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/landslide/damage4.png"),),
                        //Expanded(child:Text("www.igme.es",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.univ-brest.fr/'),
                    onTap: () {setState(() {
                      isChecked5=!isChecked5;
                    });},//onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'earthquake'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'earthquake',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Water Lines',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked5,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked5 = value!;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/landslide/damage5.png"),),
                        //Expanded(child:Text("www.univ-brest.fr",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  /*
                  FlatButton(
                    color: Colors.teal,
                    textColor: Colors.white,
                    padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                    onPressed: () {
                      /*
                      if (isChecked){rain='Yes';}else{rain='No';}
                      if (isChecked2){cas='Yes';}else{cas='No';}
                      if (evenType.compareTo('landslide')==0) {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => Landslide2(
                                evenType: evenType,
                                curLat: curLat,
                                curLon: curLon,
                                curAlt: curAlt,
                                dt: dt,
                                rain: rain,
                                cas: cas)));
                      }
                      else {

                       */
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => CaptureScreen(
                                evenType: evenType,
                                curLat: curLat,
                                curLon: curLon,
                                curAlt: curAlt,
                                dt: dt,
                                rain: rain,
                                cas: cas)));
                      //}
                    },
                    child: Text('NEXT', style: TextStyle(fontSize: 20),),
                  ),
                  RaisedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
                    },
                    //color: Colors.teal,
                    textColor: Colors.white,
                    padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                    child: Text('NEXT', style: TextStyle(fontSize: 20, backgroundColor: Colors.teal),),
                    //child: Text('Click Here To Submit Data To Server'),
                  ),
*/
        /*
                  Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [


                        /*
                        TextButton(
                            child: Text(
                                "Add to cart".toUpperCase(),
                                style: TextStyle(fontSize: 14)
                            ),
                            style: ButtonStyle(
                                padding: MaterialStateProperty.all<EdgeInsets>(EdgeInsets.all(15)),
                                foregroundColor: MaterialStateProperty.all<Color>(Colors.red),
                                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(18.0),
                                        side: BorderSide(color: Colors.red)
                                    )
                                )
                            ),
                            onPressed: () => null
                        ),
                        SizedBox(width: 10),
                        */
                        ElevatedButton(
                            child: Text(
                                "NEXT".toUpperCase(),
                                style: TextStyle(fontSize: 20)
                            ),
                            style: ButtonStyle(
                                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                                backgroundColor: MaterialStateProperty.all<Color>(Colors.teal),
                                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                        //borderRadius: BorderRadius.zero,
                                        borderRadius: BorderRadius.circular(18.0),
                                        side: BorderSide(color: Colors.teal)
                                    )
                                )
                            ), onPressed: () { Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));},
                            //onPressed: () => null
                        )
                      ]
                  ),
                  */



                  //volume of land displaced
                  //volume of land displaced
                  //volume of land displaced
                  //volume of land displaced
                  //volume of land displaced


                  InkWell(
                    //onTap: () => setState(() {
                    //
                    //}),
                    onTap: () {
                      setState(() {
                        visik = !visik;
                        print (visik);
                      });
                    },


                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'buildingsettlement'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'buildingsettlement',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www2.bgs.ac.uk/gsni/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:2,child:Text("\nOthers",style: TextStyle(fontSize: 16), textAlign: TextAlign.center,),),
                        Expanded(flex:8,child:Image.asset("images/events/others.png"),),


                        //Expanded(child:Text("www2.bgs.ac.uk/gsni",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  /*
                  InkWell(
                    //onTap: () => launch('http://www.lnec.pt/en/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'sinkhole'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'sinkhole',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.lnec.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxsinkhole.png"),),
                        Expanded(flex:2,child:Text("Sinkhole",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.lnec.pt/en",style: new TextStyle(color: Colors.blue)),),
                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.ucd.ie/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'eruption'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'eruption',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.ucd.ie/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxeruption.png"),),
                        Expanded(flex:2,child:Text("Eruption",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.ucd.ie",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),

                   */

/*                  InkWell(
                   // onTap: () => launch('https://www.cerema.fr/fr'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p9x.png"),),
                        Expanded(child:Text("Centre d’Etudes et d’Expertise sur les Risques Environnement Mobilité et Aménagement",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.lneg.pt/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.lneg.pt/",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p10x.png"),),
                        Expanded(child:Text("Laboratório Nacional de Energia e Geologia",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.lneg.pt",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),


                  InkWell(
                    //onTap: () => launch('https://www.uma.pt/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.uma.pt/",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p11x.png"),),
                        Expanded(child:Text("Universidade da Madeira",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.uma.pt",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                   // onTap: () => launch('https://www.ull.es/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.ull.es/",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p12x.png"),),
                        Expanded(child:Text("Universidad de La Laguna",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.ull.es",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.cm-lisboa.pt/en'),
                    //onTap: () => launch('https://www.lisboa.pt/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p13x.png"),),
                        Expanded(child:Text("Câmara Municipal de Lisboa",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
*/

                ])),

        Visibility(
            visible: visik,
            child:
            TextFormField(
                //enabled: _isEnable,
                maxLines: 2,
                decoration: InputDecoration(
                  //border: UnderlineInputBorder(),
                    border: OutlineInputBorder(),
                    labelText: 'Any extra comments ?',),
                    //hintText: "Please enter any extra comments about the event here..."),
                //controller: commentsController,
                onChanged: (var newval){
                  setState((){
                    //casualtyValue = newval;
                    //_DBupdate(imgmd5,'comments',newval);
                    //commentsController.text = newval.toString();
                  });

                }


            )
        ),

            Align(
            alignment: Alignment.bottomCenter,
    child:
    Column(children:[
    //Divider(height: 15,thickness: 0,),

        ElevatedButton(
          child: Text(
              "               NEXT               ".toUpperCase(),
              style: TextStyle(fontSize: 20)
          ),
          style: ButtonStyle(
              foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
              backgroundColor: MaterialStateProperty.all<Color>(Colors.teal),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    //borderRadius: BorderRadius.zero,
                      borderRadius: BorderRadius.circular(18.0),
                      side: BorderSide(color: Colors.teal)
                  )
              )
          ), onPressed: () { Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));},
          //onPressed: () => null
        ),
    Divider(height: 15,thickness: 0,),
    ]),),

        ])
        )

      /*Center(
          // Add a ListView to the drawer. This ensures the user can scroll
          // through the options in the drawer if there isn't enough vertical
          // space to fit everything.
            child:
        Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text("Our Partners",style: Theme.of(context).textTheme.headline6,),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://tecnico.ulisboa.pt/en/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p1.png"),
                        Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),
                        //Text("https://tecnico.ulisboa.pt/en/"),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
            child: InkWell(
              onTap: () => launch('http://www.apgeologos.pt/'),
              child: Row(
                children: <Widget>[
                  //Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),
                  Image.asset("images/partners/p2.png"),
                  Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),

                ],
              ),
            ),
          ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.lapalmacentre.eu/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.lapalmacentre.eu/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p3.png"),
                        Text("https://www.lapalmacentre.eu/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('http://www.igme.es/'),
                    child: Row(
                      children: <Widget>[
                        //Text("http://www.igme.es/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p4.jpg"),
                        Text("http://www.igme.es/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.univ-brest.fr/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p5.jpg"),
                        Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www2.bgs.ac.uk/gsni/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www2.bgs.ac.uk/gsni/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p6.jpg"),
                        Text("https://www2.bgs.ac.uk/gsni/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('http://www.lnec.pt/en/'),
                    child: Row(
                      children: <Widget>[
                        //Text("http://www.lnec.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p7.jpg"),
                        Text("http://www.lnec.pt/en/",style: new TextStyle(color: Colors.blue)),
                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.ucd.ie/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.ucd.ie/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p8.jpg"),
                        Text("https://www.ucd.ie/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.cerema.fr/fr'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p9.jpg"),
                        Text("https://www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.lneg.pt/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.lneg.pt/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p10.jpg"),
                        Text("https://www.lneg.pt/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.uma.pt/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.uma.pt/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p11.png"),
                        Text("https://www.uma.pt/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.ull.es/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.ull.es/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p12.jpg"),
                        Text("https://www.ull.es/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('http://www.cm-lisboa.pt/en'),
                    child: Row(
                      children: <Widget>[
                        //Text("http://www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p13.jpg"),
                        Text("http://www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                /*
                Expanded(child:Image(image: AssetImage('images/partners/p1.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p2.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p3.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p4.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p5.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p6.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p7.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p8.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p9.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p10.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p11.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p12.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p13.jpg',),),),

                 */
                /*
                GestureDetector(
                  //onTap: _launchURL(1),
                  onTap: () => launch('https://google.com/'),
                  child: Image.asset(
                    'images/partners/p13.jpg', // On click should redirect to an URL
                    width: 400.0,
                    height: 180.0,
                    fit: BoxFit.cover,
                  ),
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://google.com/'),
                    child: Stack(
                      children: <Widget>[
                        Image.asset("images/partners/p12.jpg"),
                        Text("https://google.com/"),
                      ],
                    ),
                  ),
                ),
                */
  ],
        ),)

         */







    );

  }
}
class CustomTrackShape extends RoundedRectSliderTrackShape {
  Rect getPreferredRect({
    required RenderBox parentBox,
    Offset offset = Offset.zero,
    required SliderThemeData sliderTheme,
    bool isEnabled = false,
    bool isDiscrete = false,
  }) {
    final double? trackHeight = sliderTheme.trackHeight;
    final double trackLeft = offset.dx;
    final double trackTop = offset.dy + (parentBox.size.height - trackHeight!) / 2;
    final double trackWidth = parentBox.size.width;
    return Rect.fromLTWH(trackLeft, trackTop, trackWidth, trackHeight);
  }
}