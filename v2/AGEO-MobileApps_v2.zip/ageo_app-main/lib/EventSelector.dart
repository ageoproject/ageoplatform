import 'package:flutter/material.dart';

import 'LocationDate.dart';

class EventSelector extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Select Event Type'),
        ),


        body:
        Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.lightBlueAccent, Colors.white])
            ),

            child:
            GridView.count(
                primary: false,
                padding: const EdgeInsets.all(5),
                crossAxisCount: MediaQuery.of(context).size.width > 700 ? 4 : 2,

                crossAxisSpacing: 20,
                mainAxisSpacing: 0.1,
                //crossAxisCount: 2,
                children: <Widget>[
                  InkWell(
                    //onTap: () => launch('https://tecnico.ulisboa.pt/en/'),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => PartnersScreen())),
                    //onTap: () => Navigator.pop(context),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen())),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'landslide',))),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'landslide',))),
                    child:Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxlandslide.png"),),
                        Expanded(flex:2,child:Text("Landslide",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("tecnico.ulisboa.pt/en",style: new TextStyle(color: Colors.blue)),),
                        //Text("https://tecnico.ulisboa.pt/en/"),

                      ],
                    ),),
                  InkWell(
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen())),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'rockslide',))),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'rockslide',))),
                    //onTap: () => launch('http://www.apgeologos.pt/'),
                    child:
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxrockslide.png"),),
                        Expanded(flex:2,child:Text("Rockfall",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.apgeologos.pt",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),),
                  InkWell(
                    //onTap: () => launch('https://www.lapalmacentre.eu/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'tsunami'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'tsunami',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.lapalmacentre.eu/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxtsunami.png"),),
                        //Image.asset("images/events/xxtsunami.png"),
                        //Text("Tsunami",textAlign: TextAlign.center,),
                        Expanded(flex:2,child:Text("Tsunami",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.lapalmacentre.eu",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),


                  InkWell(
                    //onTap: () => launch('https://www.igme.es/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'flood'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'flood',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.igme.es/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxflood.png"),),
                        Expanded(flex:2,child:Text("Flood",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.igme.es",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.univ-brest.fr/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'earthquake'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'earthquake',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxearthquake.png"),),
                        Expanded(flex:2,child:Text("Earthquake",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.univ-brest.fr",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www2.bgs.ac.uk/gsni/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'buildingsettlement'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'buildingsettlement',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www2.bgs.ac.uk/gsni/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxbuildingsettlement.png"),),
                        Expanded(flex:2,child:Text("Building Settlement",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www2.bgs.ac.uk/gsni",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('http://www.lnec.pt/en/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'sinkhole'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'sinkhole',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.lnec.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxsinkhole.png"),),
                        Expanded(flex:2,child:Text("Sinkhole",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.lnec.pt/en",style: new TextStyle(color: Colors.blue)),),
                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.ucd.ie/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'eruption'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'eruption',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.ucd.ie/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxeruption.png"),),
                        Expanded(flex:2,child:Text("Eruption",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.ucd.ie",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
/*                  InkWell(
                   // onTap: () => launch('https://www.cerema.fr/fr'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p9x.png"),),
                        Expanded(child:Text("Centre d’Etudes et d’Expertise sur les Risques Environnement Mobilité et Aménagement",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.lneg.pt/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.lneg.pt/",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p10x.png"),),
                        Expanded(child:Text("Laboratório Nacional de Energia e Geologia",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.lneg.pt",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),


                  InkWell(
                    //onTap: () => launch('https://www.uma.pt/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.uma.pt/",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p11x.png"),),
                        Expanded(child:Text("Universidade da Madeira",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.uma.pt",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                   // onTap: () => launch('https://www.ull.es/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.ull.es/",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p12x.png"),),
                        Expanded(child:Text("Universidad de La Laguna",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.ull.es",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.cm-lisboa.pt/en'),
                    //onTap: () => launch('https://www.lisboa.pt/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p13x.png"),),
                        Expanded(child:Text("Câmara Municipal de Lisboa",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
*/

                ]))

      /*Center(
          // Add a ListView to the drawer. This ensures the user can scroll
          // through the options in the drawer if there isn't enough vertical
          // space to fit everything.
            child:
        Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text("Our Partners",style: Theme.of(context).textTheme.headline6,),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://tecnico.ulisboa.pt/en/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p1.png"),
                        Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),
                        //Text("https://tecnico.ulisboa.pt/en/"),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
            child: InkWell(
              onTap: () => launch('http://www.apgeologos.pt/'),
              child: Row(
                children: <Widget>[
                  //Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),
                  Image.asset("images/partners/p2.png"),
                  Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),

                ],
              ),
            ),
          ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.lapalmacentre.eu/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.lapalmacentre.eu/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p3.png"),
                        Text("https://www.lapalmacentre.eu/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('http://www.igme.es/'),
                    child: Row(
                      children: <Widget>[
                        //Text("http://www.igme.es/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p4.jpg"),
                        Text("http://www.igme.es/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.univ-brest.fr/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p5.jpg"),
                        Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www2.bgs.ac.uk/gsni/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www2.bgs.ac.uk/gsni/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p6.jpg"),
                        Text("https://www2.bgs.ac.uk/gsni/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('http://www.lnec.pt/en/'),
                    child: Row(
                      children: <Widget>[
                        //Text("http://www.lnec.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p7.jpg"),
                        Text("http://www.lnec.pt/en/",style: new TextStyle(color: Colors.blue)),
                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.ucd.ie/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.ucd.ie/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p8.jpg"),
                        Text("https://www.ucd.ie/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.cerema.fr/fr'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p9.jpg"),
                        Text("https://www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.lneg.pt/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.lneg.pt/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p10.jpg"),
                        Text("https://www.lneg.pt/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.uma.pt/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.uma.pt/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p11.png"),
                        Text("https://www.uma.pt/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.ull.es/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.ull.es/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p12.jpg"),
                        Text("https://www.ull.es/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('http://www.cm-lisboa.pt/en'),
                    child: Row(
                      children: <Widget>[
                        //Text("http://www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p13.jpg"),
                        Text("http://www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                /*
                Expanded(child:Image(image: AssetImage('images/partners/p1.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p2.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p3.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p4.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p5.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p6.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p7.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p8.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p9.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p10.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p11.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p12.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p13.jpg',),),),

                 */
                /*
                GestureDetector(
                  //onTap: _launchURL(1),
                  onTap: () => launch('https://google.com/'),
                  child: Image.asset(
                    'images/partners/p13.jpg', // On click should redirect to an URL
                    width: 400.0,
                    height: 180.0,
                    fit: BoxFit.cover,
                  ),
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://google.com/'),
                    child: Stack(
                      children: <Widget>[
                        Image.asset("images/partners/p12.jpg"),
                        Text("https://google.com/"),
                      ],
                    ),
                  ),
                ),
                */
  ],
        ),)

         */







    );
  }
}