import 'package:flutter/material.dart';

import 'CaptureScreen.dart';
import 'LocationDate.dart';
import 'package:number_inc_dec/number_inc_dec.dart';


class Earthquake2 extends StatefulWidget {

  String evenType;
  double curLat;
  double curLon;
  double curAlt;
  String dt;
  String rain;
  String cas;

  Earthquake2({Key? key,required this.evenType, required this.curLat, required this.curLon, required this.curAlt, required this.dt, required this.rain, required this.cas}) : super(key: key);



  @override
  _SingleImageUploadState createState() {
    return _SingleImageUploadState(this.evenType,this.curLat,this.curLon,this.curAlt, this.dt, this.rain, this.cas);
  }
}

class _SingleImageUploadState extends State<Earthquake2> {

//class Landslide2 extends StatelessWidget {

  bool isChecked1 = false;
  bool isChecked2 = false;
  bool isChecked3 = false;
  bool isChecked4 = false;
  bool isChecked5 = false;
  bool isChecked6 = false;


  bool visibleSend = false;
  bool visibleSens = true;

  String evenType;
  double curLat;
  double curLon;
  double curAlt;
  String dt;
  String rain;
  String cas;

  double _currentSliderValue = 0.3;
  String gerzek = '';

  // Initial Selected Value
  String dropdownvalue = '     1     '+'\n';
  String dropdownvalue2 = '1'+'\n';
  //String dropdownvalue3 = '1'+'\n';
  String dropdownvalue3 = '1';

  // List of items in our dropdown menu
  var items = [
    '     1     '+'\n',
    '     2     '+'\n',
    '     3     '+'\n',
    '     4     '+'\n',
    '     5     '+'\n',
    '     6+    '+'\n',
  ];

  var items2 = [
    '1'+'\n',
    '2'+'\n',
    '3'+'\n',
    '4'+'\n',
    '5'+'\n',
    '6+'+'\n',
  ];
  var items3 = [
    '1',
    '2',
    '3',
    '4',
    '5',
    '6+',
  ];


  _SingleImageUploadState(this.evenType,this.curLat,this.curLon,this.curAlt, this.dt, this.rain, this.cas);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Damage on Buildings'),
        ),


        body:
        Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.lightBlueAccent, Colors.white])
            ),

            child:
            Column(
                children: [

                  //Divider(),
                    //Spacer( flex: 1,),
                    Text('Number of Floors', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white,),),
                    //DropdownButtonFormField(
            //Container(
            //    width: 150,
            //    color: Colors.white,
            //    child:
                        DropdownButton(

/*
                      decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          //fillColor: Hexcolor('#ecedec'),
                          labelText: 'Number of Floors',
                          labelStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black,)

                        //contentPadding: EdgeInsets.zero,
                        //border: new CustomBorderTextFieldSkin().getSkin(),
                      ),

 */
                      // Initial Value
                          dropdownColor: Colors.white,
                      focusColor: Colors.white,
                      iconDisabledColor: Colors.white,
                      iconEnabledColor: Colors.white,
                      value: dropdownvalue3,

                      // Down Arrow Icon
                      icon: const Icon(Icons.keyboard_arrow_down),

                      // Array list of items
                      items: items3.map((String items) {
                        return DropdownMenuItem(
                          value: items,
                          child:Container(
                          alignment: Alignment.center,
                          //constraints: BoxConstraints(minHeight: 48.0),
                          color: Colors.white,
                          width: 100,
                          child: Text(items, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, backgroundColor: Colors.white, decorationColor: Colors.white), textAlign: TextAlign.center,),
                        ),
                        );
                      }).toList(),
                      // After selecting the desired option,it will
                      // change button value to selected value
                      onChanged: (String? newValue) {
                        setState(() {
                          dropdownvalue3 = newValue!;
                        });
                      },
                    ),
                  //Divider(),
                //Spacer(flex: 1,),
                //),





                  /*
                  Container(
                    width: 150,
                    child:DropdownButtonFormField(

                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      //fillColor: Hexcolor('#ecedec'),
                      labelText: 'Number of Floors',
                        labelStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black,)

                      //contentPadding: EdgeInsets.zero,
                      //border: new CustomBorderTextFieldSkin().getSkin(),
                    ),
                    // Initial Value
                    value: dropdownvalue,

                    // Down Arrow Icon
                    icon: const Icon(Icons.keyboard_arrow_down),

                    // Array list of items
                    items: items.map((String items) {
                      return DropdownMenuItem(
                        value: items,
                        child: Text(items, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold,), textAlign: TextAlign.center,),
                      );
                    }).toList(),
                    // After selecting the desired option,it will
                    // change button value to selected value
                    onChanged: (String? newValue) {
                      setState(() {
                        dropdownvalue = newValue!;
                      });
                    },
                  ),),

                   */

            Expanded(
                child:
            ListView(
            //padding: const EdgeInsets.all(100),
                //padding: EdgeInsets.symmetric(horizontal: 10),
                //padding: const EdgeInsets.all(10),// add margin

                padding: EdgeInsets.only (left: MediaQuery.of(context).size.width*0.05,right: MediaQuery.of(context).size.width*0.05),

                children: <Widget>[
                  //Divider(height: 5,color: Colors.tealAccent,),
                  InkWell(
                    onTap: () {
                      print("tapped on container");
                      setState(() {
                        visibleSend = true;
                        isChecked1 = true;
                        isChecked2 = false;
                        isChecked3 = false;
                        isChecked4 = false;
                      });
                      //Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
                    },
                    child: Container(
                //padding: EdgeInsets.only (left: MediaQuery.of(context).size.width/10,right: MediaQuery.of(context).size.width/10),
                    padding: EdgeInsets.symmetric(vertical: 5),
                        //height:  MediaQuery.of(context).size.width/3.25,
                        height: MediaQuery.of(context).size.height/6,
                    //height: MediaQuery.of(context).size.height*.4,
                    alignment: Alignment.center,
                color: isChecked1 ? Colors.tealAccent :  Colors.green[600],
                child:Row(
                  children: <Widget>[
                    SizedBox(width: 15),
                    Image.asset("images/events/earthquake/damage1.png",),
                    SizedBox(width: 15),
                    Expanded(
                        child:
                        Align(
                          alignment: Alignment.center,
                          child:
                          Text('Falling objects\n(non-structural elements)', textAlign:TextAlign.justify, /*textAlign: TextAlign.center,*/style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold), ),
                        )),
                    //Text('Falling objects (non-structural elements)'),

                    SizedBox(width: 15),

                  ],

                )
                ),),
                  //Divider(),
                  //Divider(height: 1,color: Colors.tealAccent,),
                  Divider(height: 5,color: Colors.tealAccent,),
                  InkWell(
                    onTap: () {
                      print("tapped on container");
                      setState(() {
                        visibleSend = true;
                        //visibleSens = true;
                        isChecked2 = true;
                        isChecked1 = false;
                        isChecked3 = false;
                        isChecked4 = false;
                      });
                      //Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
                    },
                    child: Container(
                    padding: EdgeInsets.symmetric(vertical: 5),
                        //height:  MediaQuery.of(context).size.width/3.25,
                        height: MediaQuery.of(context).size.height/6,
                    //height: MediaQuery.of(context).size.height*0.4,

                    alignment: Alignment.center,
                    color: isChecked2 ? Colors.tealAccent : Colors.yellow[600],
                    child:Row(
                      children: <Widget>[
                        SizedBox(width: 15),
                        Image.asset("images/events/earthquake/damage2.png",),
                        SizedBox(width: 15),

                        //Text('Minor Damage'),
                        Expanded(
                            child:
                            Align(
                              alignment: Alignment.center,
                              child:
                              Text('Minor Damage', textAlign:TextAlign.justify, /*textAlign: TextAlign.center,*/style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold), ),
                            )),

                        SizedBox(width: 15),

                      ],

                    )
                ),),
                  //Divider(),
                  //Divider(height: 1,color: Colors.tealAccent,),
                  Divider(height: 5,color: Colors.tealAccent,),
    InkWell(
    onTap: () {
    print("tapped on container");
    setState(() {
      visibleSend = true;
      isChecked3 = true;
      isChecked2 = false;
      isChecked1 = false;
      isChecked4 = false;
    });
    //Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
    },
    child: Container(
                    padding: EdgeInsets.symmetric(vertical: 5),
                    //height:  MediaQuery.of(context).size.width/3.25,
        height: MediaQuery.of(context).size.height/6,
                    //height: MediaQuery.of(context).size.height*0.4,

                    alignment: Alignment.center,
                    color: isChecked3 ? Colors.tealAccent : Colors.orange[600],
                        child:Row(
                          children: <Widget>[
                            SizedBox(width: 15),
                            Image.asset("images/events/earthquake/damage3.png",),
                            SizedBox(width: 15),
                            Expanded(
                                child:
                                Align(
                                  alignment: Alignment.center,
                                  child:
                                  Text('Moderate Damage', textAlign:TextAlign.justify, /*textAlign: TextAlign.center,*/style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold), ),
                                )),
                            //Text('Moderate Damage'),
                            SizedBox(width: 15),
                          ],

                        )
                ),),
                  //Divider(height: 1,color: Colors.teal,),
                  Divider(height: 5,color: Colors.tealAccent,),
                          InkWell(
                          onTap: () {
    print("tapped on container");
    setState(() {
      visibleSend = true;
      isChecked4 = true;
      isChecked2 = false;
      isChecked3 = false;
      isChecked1 = false;
    });
    //Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
    },
    child: Container(
                  //padding: EdgeInsets.all(5),
                  //padding: EdgeInsets.only(left: 10),
                  padding: EdgeInsets.symmetric(vertical: 5),
        //height:  MediaQuery.of(context).size.width/3.25,
        height: MediaQuery.of(context).size.height/6,
                  //height: MediaQuery.of(context).size.height*0.4,
                alignment: Alignment.center,
                color: isChecked4 ? Colors.tealAccent : Colors.red[600],
                child:Row(
                  //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    SizedBox(width: 15),
                    //Spacer(flex: 1,),
                    Image.asset("images/events/earthquake/damage4.png",),
                    SizedBox(width: 15),
                    //Spacer(flex: 1,),
                    //Flexible(
                  Expanded(
                      child:
                      Align(
                    alignment: Alignment.center,
                    child:
                    Text('Partial or Total Collaps', textAlign:TextAlign.justify, /*textAlign: TextAlign.center,*/style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold), ),
                  )),
                    SizedBox(width: 15),
                  ],

                )
              ),),
                  //Divider(height: 5,color: Colors.tealAccent,),
             /*
            GridView.count(
                primary: false,
                padding: const EdgeInsets.all(5),

                crossAxisSpacing: 20,
                mainAxisSpacing: 0.1,
                crossAxisCount: 2,
                children: <Widget>[
                  //Text('Observed Damage',textAlign: TextAlign.left),
                  InkWell(
                    //onTap: () => launch('https://tecnico.ulisboa.pt/en/'),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => PartnersScreen())),
                    //onTap: () => Navigator.pop(context),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen())),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'landslide',))),
                    onTap: () {setState(() {
                      isChecked1=!isChecked1;
                      isChecked6 = false;
                    });},//onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'landslide',))),
                    child:Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),

                        //Expanded(flex:2,child:Text("Landslide",textAlign: TextAlign.center,),),
                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Vertical',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked1,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked1 = value!;
                              isChecked6 = false;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/building/direction1.png"),),
                        //Expanded(child:Text("tecnico.ulisboa.pt/en",style: new TextStyle(color: Colors.blue)),),
                        //Text("https://tecnico.ulisboa.pt/en/"),

                      ],
                    ),),
                  InkWell(
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen())),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'rockslide',))),
                    onTap: () {setState(() {
                      isChecked2=!isChecked2;
                      isChecked6 = false;
                    });},//onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'rockslide',))),
                    //onTap: () => launch('http://www.apgeologos.pt/'),
                    child:
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Horizontal',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked2,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked2 = value!;
                              isChecked6 = false;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/building/direction2.png"),),
                        //Expanded(child:Text("www.apgeologos.pt",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),),
                  InkWell(
                    //onTap: () => launch('https://www.lapalmacentre.eu/'),
                    onTap: () {setState(() {
                      isChecked3=!isChecked3;
                      isChecked6 = false;
                    });},//onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'tsunami'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'tsunami',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.lapalmacentre.eu/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Oblique',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked3,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked3 = value!;
                              isChecked6 = false;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/building/direction3.png"),),
                        //Expanded(child:Text("www.lapalmacentre.eu",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),


                  InkWell(
                    //onTap: () => launch('https://www.igme.es/'),
                    onTap: () {setState(() {
                      isChecked4=!isChecked4;
                      isChecked6 = false;
                    });},//=> Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'flood'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'flood'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'flood',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.igme.es/",style: new TextStyle(color: Colors.blue)),

                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Oblique',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked4,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked4 = value!;
                              isChecked6 = false;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/building/direction4.png"),),
                        //Expanded(child:Text("www.igme.es",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.univ-brest.fr/'),
                    onTap: () {setState(() {
                      isChecked5=!isChecked5;
                      isChecked6 = false;
                    });},//onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'earthquake'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'earthquake',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('Starry',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked5,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked5 = value!;
                              isChecked6 = false;
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/building/direction5.png"),),
                        //Expanded(child:Text("www.univ-brest.fr",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.univ-brest.fr/'),
                    onTap: () {setState(() {
                      isChecked6=!isChecked6;
                      if (isChecked6) {
                        isChecked1 = false;
                        isChecked2 = false;
                        isChecked3 = false;
                        isChecked4 = false;
                        isChecked5 = false;
                        gerzek = '';
                      }
                    });},//onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'earthquake'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'earthquake',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:2,child:
                        CheckboxListTile(
                          controlAffinity: ListTileControlAffinity.leading,
                          //secondary: const Icon(Icons.alarm),
                          title: const Text('No Cracks',textAlign: TextAlign.left),
                          //subtitle: Text('Select if there are people at risk'),
                          value: isChecked6,
                          onChanged: (bool? value) {
                            setState(() {
                              isChecked6 = value!;
                              if (isChecked6) {
                                isChecked1 = false;
                                isChecked2 = false;
                                isChecked3 = false;
                                isChecked4 = false;
                                isChecked5 = false;
                                gerzek = '';
                              }
                            });
                          },
                        )
                          ,),
                        Expanded(flex:8,child:Image.asset("images/events/building/direction6.png"),),
                        //Expanded(child:Text("www.univ-brest.fr",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  /*
                  FlatButton(
                    color: Colors.teal,
                    textColor: Colors.white,
                    padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                    onPressed: () {
                      /*
                      if (isChecked){rain='Yes';}else{rain='No';}
                      if (isChecked2){cas='Yes';}else{cas='No';}
                      if (evenType.compareTo('landslide')==0) {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => Landslide2(
                                evenType: evenType,
                                curLat: curLat,
                                curLon: curLon,
                                curAlt: curAlt,
                                dt: dt,
                                rain: rain,
                                cas: cas)));
                      }
                      else {

                       */
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => CaptureScreen(
                                evenType: evenType,
                                curLat: curLat,
                                curLon: curLon,
                                curAlt: curAlt,
                                dt: dt,
                                rain: rain,
                                cas: cas)));
                      //}
                    },
                    child: Text('NEXT', style: TextStyle(fontSize: 20),),
                  ),
                  RaisedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
                    },
                    //color: Colors.teal,
                    textColor: Colors.white,
                    padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                    child: Text('NEXT', style: TextStyle(fontSize: 20, backgroundColor: Colors.teal),),
                    //child: Text('Click Here To Submit Data To Server'),
                  ),
*/
        /*
                  Divider(),
                  Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [


                        /*
                        TextButton(
                            child: Text(
                                "Add to cart".toUpperCase(),
                                style: TextStyle(fontSize: 14)
                            ),
                            style: ButtonStyle(
                                padding: MaterialStateProperty.all<EdgeInsets>(EdgeInsets.all(15)),
                                foregroundColor: MaterialStateProperty.all<Color>(Colors.red),
                                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(18.0),
                                        side: BorderSide(color: Colors.red)
                                    )
                                )
                            ),
                            onPressed: () => null
                        ),
                        SizedBox(width: 10),
                        */
                        ElevatedButton(
                            child: Text(
                                "NEXT".toUpperCase(),
                                style: TextStyle(fontSize: 20)
                            ),
                            style: ButtonStyle(
                                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                                backgroundColor: MaterialStateProperty.all<Color>(Colors.teal),
                                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                        //borderRadius: BorderRadius.zero,
                                        borderRadius: BorderRadius.circular(18.0),
                                        side: BorderSide(color: Colors.teal)
                                    )
                                )
                            ), onPressed: () { Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));},
                            //onPressed: () => null
                        )
                      ]
                  )
                  */

                  /*
                  InkWell(
                    //onTap: () => launch('https://www2.bgs.ac.uk/gsni/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'buildingsettlement'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'buildingsettlement',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www2.bgs.ac.uk/gsni/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxbuildingsettlement.png"),),
                        Expanded(flex:2,child:Text("Building Settlement",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www2.bgs.ac.uk/gsni",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('http://www.lnec.pt/en/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'sinkhole'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'sinkhole',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.lnec.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxsinkhole.png"),),
                        Expanded(flex:2,child:Text("Sinkhole",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.lnec.pt/en",style: new TextStyle(color: Colors.blue)),),
                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.ucd.ie/'),
                    onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(evenType: 'eruption'))),
                    //onTap: () => Navigator.push(context,MaterialPageRoute(builder: (context) => LocationDateScreen(event_type: 'eruption',))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.ucd.ie/",style: new TextStyle(color: Colors.blue)),
                        Expanded(flex:8,child:Image.asset("images/events/xxeruption.png"),),
                        Expanded(flex:2,child:Text("Eruption",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.ucd.ie",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),

                   */

/*                  InkWell(
                   // onTap: () => launch('https://www.cerema.fr/fr'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p9x.png"),),
                        Expanded(child:Text("Centre d’Etudes et d’Expertise sur les Risques Environnement Mobilité et Aménagement",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.lneg.pt/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.lneg.pt/",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p10x.png"),),
                        Expanded(child:Text("Laboratório Nacional de Energia e Geologia",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.lneg.pt",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),


                  InkWell(
                    //onTap: () => launch('https://www.uma.pt/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.uma.pt/",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p11x.png"),),
                        Expanded(child:Text("Universidade da Madeira",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.uma.pt",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                   // onTap: () => launch('https://www.ull.es/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("https://www.ull.es/",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p12x.png"),),
                        Expanded(child:Text("Universidad de La Laguna",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.ull.es",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
                  InkWell(
                    //onTap: () => launch('https://www.cm-lisboa.pt/en'),
                    //onTap: () => launch('https://www.lisboa.pt/'),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        //Text("http://www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),
                        Expanded(child:Image.asset("images/partners/p13x.png"),),
                        Expanded(child:Text("Câmara Municipal de Lisboa",textAlign: TextAlign.center,),),
                        //Expanded(child:Text("www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),),

                      ],
                    ),
                  ),
*/

                ]),
                */

            ]),
            ),

    Align(
    alignment: Alignment.bottomCenter,
    child:
    Column(children:[
    //Divider(height: 15,thickness: 0,),
                  Center(

                      child:
                          Column( children: [
                            Visibility(
                                visible: !visibleSend && !visibleSens,
                                child:
                                Center(child:Text('Please select an option above',style: TextStyle(fontSize: 18, color: Colors.red) ,))

                            ),

                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                ElevatedButton(
                                  child: Text(
                                    //"ADD OTHER BUILDING".toUpperCase(),
                                      "Add Another Building",
                                      style: TextStyle(fontSize: 20)
                                  ),
                                  style: ButtonStyle(
                                    //foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                                    //backgroundColor: MaterialStateProperty.all<Color>(Colors.teal),
                                      foregroundColor: !visibleSend ? MaterialStateProperty.all<Color>(Colors.white.withOpacity(0.3)) : MaterialStateProperty.all<Color>(Colors.white),
                                      backgroundColor: !visibleSend ? MaterialStateProperty.all<Color>(Colors.teal.withOpacity(0.3)) : MaterialStateProperty.all<Color>(Colors.teal),
                                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                          RoundedRectangleBorder(
                                            //borderRadius: BorderRadius.zero,
                                              borderRadius: BorderRadius.circular(18.0),
                                              side: BorderSide(color: Colors.teal)
                                          )
                                      )
                                  ), onPressed: () {
                                  if (!visibleSend)
                                  {
                                    print ('vd' + visibleSend.toString());
                                    print ('vs' +visibleSens.toString());
                                    print('siktir');
                                    int thisisnotwhatyouarelookingfor=0;
                                    setState(() {visibleSens=false;});
                                  } else {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(builder: (context) => Earthquake2(
                                            evenType: evenType,
                                            curLat: curLat,
                                            curLon: curLon,
                                            curAlt: curAlt,
                                            dt: dt,
                                            rain: rain,
                                            cas: cas)));
                                    //Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
                                  }},



                                  //onPressed: () => null
                                ),
                                Divider(indent: 25,),
                                ElevatedButton(
                                  child: Text(
                                      "NEXT".toUpperCase(),
                                      style: TextStyle(fontSize: 20)
                                  ),
                                  style: ButtonStyle(
                                    //foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                                    //backgroundColor: MaterialStateProperty.all<Color>(Colors.teal),
                                      foregroundColor: !visibleSend ? MaterialStateProperty.all<Color>(Colors.white.withOpacity(0.3)) : MaterialStateProperty.all<Color>(Colors.white),
                                      backgroundColor: !visibleSend ? MaterialStateProperty.all<Color>(Colors.teal.withOpacity(0.3)) : MaterialStateProperty.all<Color>(Colors.teal),
                                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                          RoundedRectangleBorder(
                                            //borderRadius: BorderRadius.zero,
                                              borderRadius: BorderRadius.circular(18.0),
                                              side: BorderSide(color: Colors.teal)
                                          )
                                      )
                                  ), onPressed: () {
                                  if (!visibleSend)
                                  {
                                    print ('vd' + visibleSend.toString());
                                    print ('vs' +visibleSens.toString());
                                    print('siktir');
                                    int thisisnotwhatyouarelookingfor=0;
                                    setState(() {visibleSens=false;});
                                  } else {
                                    Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
                                    /*
                                    Navigator.of(context).push(
                                        MaterialPageRoute(builder: (context) => Earthquake2(
                                            evenType: evenType,
                                            curLat: curLat,
                                            curLon: curLon,
                                            curAlt: curAlt,
                                            dt: dt,
                                            rain: rain,
                                            cas: cas)));

                                     */
                                    //Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));
                                  }},


                                  //onPressed: () => null
                                )

                              ],
                            ),
                          ],
                          )
                      ),
      Divider(height: 15,thickness: 0,),
    ]),),


                  //Divider(),
                  /*
                  Align(
                    alignment: Alignment.centerLeft,
                    child:
                    Text('Dimension of crack (in millimeters)',style: TextStyle(fontSize: 20,color: Colors.teal,),textAlign: TextAlign.left,),
                  ),

                   */

/*
            Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24.0),
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: List.generate(6, (index) => Text((index+1).toString())),
                  ),
                  ),
            */
                  //Row(children: <Widget>[
                  //Expanded(flex:8,child:
                  //Container(width: MediaQuery.of(context).size.width*0.3,child:
                  //Image.asset("images/events/sinkhole/steps.png"),//),),
                  //Container(width: MediaQuery.of(context).size.width*0.7,child:
    /*
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      //activeTrackColor: Colors.red[700],
                      //inactiveTrackColor: Colors.red[100],
                      trackShape: RoundedRectSliderTrackShape(),
                      trackHeight: 4.0,
                      thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12.0),
                      //thumbColor: Colors.redAccent,
                      //overlayColor: Colors.red.withAlpha(32),
                      overlayShape: RoundSliderOverlayShape(overlayRadius: 28.0),
                      tickMarkShape: RoundSliderTickMarkShape(),
                      //activeTickMarkColor: Colors.red[700],
                      //inactiveTickMarkColor: Colors.red[100],
                      valueIndicatorShape: PaddleSliderValueIndicatorShape(),
                      //valueIndicatorColor: Colors.redAccent,
                      valueIndicatorTextStyle: TextStyle(
                        color: Colors.teal,
                      ),
                    ),
                    child:Slider(
                      activeColor: Colors.tealAccent,
                      inactiveColor: Colors.teal,
                      thumbColor: Colors.tealAccent,
                      mouseCursor: MouseCursor.defer,
                      autofocus : true,
                      value: _currentSliderValue,
                      min: 0.3,
                      max: 15,
                      divisions: 20,
                      label: (_currentSliderValue==15) ? '>'+_currentSliderValue.toStringAsFixed(1) : '<'+_currentSliderValue.toStringAsFixed(1),
                      //label: (_currentSliderValue==15) ? '>'+_currentSliderValue.round().toString() : '<'+_currentSliderValue.round().toString(),

                      /*
              onChangeStart: (double value) {
                print('Start value is ' + value.toString());
              },

               */

                      onChangeEnd: (double value) {
                        if (value==15)
                        {
                          setState(() {
                            //gerzek = '>'+value.round().toString() +' millimeters selected.';
                            gerzek = '>'+value.toStringAsFixed(1) +' millimeters selected.';
                          });
                          print(value.round().toString() +' step.' );

                        }
                        /*
                        else if (value==6)
                        {
                          setState(() {
                            gerzek = value.round().toString() +'+ steps selected.';
                          });

                        }

                         */
                        else {
                          setState(() {
                            gerzek = '<'+value.toStringAsFixed(1) +' millimeters selected.';
                          });

                          print(value.round().toString() +' steps.' );
                        }
                      },


                      onChanged: (double value) {
                        setState(() {
                          _currentSliderValue = value;
                        });
                      },
                    ),),//)
                  //],),

                  Text(gerzek),
                  ElevatedButton(
                    child: Text(
                        "NEXT".toUpperCase(),
                        style: TextStyle(fontSize: 20)
                    ),
                    style: ButtonStyle(
                        foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                        backgroundColor: MaterialStateProperty.all<Color>(Colors.teal),
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              //borderRadius: BorderRadius.zero,
                                borderRadius: BorderRadius.circular(18.0),
                                side: BorderSide(color: Colors.teal)
                            )
                        )
                    ), onPressed: () { Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CaptureScreen(evenType: evenType,curLat: curLat,curLon: curLon, curAlt: curAlt, dt: dt,rain: rain, cas: cas)));},
                    //onPressed: () => null
                  )
                  */

                ])
        )

      /*Center(
          // Add a ListView to the drawer. This ensures the user can scroll
          // through the options in the drawer if there isn't enough vertical
          // space to fit everything.
            child:
        Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text("Our Partners",style: Theme.of(context).textTheme.headline6,),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://tecnico.ulisboa.pt/en/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p1.png"),
                        Text("https://tecnico.ulisboa.pt/en/",style: new TextStyle(color: Colors.blue)),
                        //Text("https://tecnico.ulisboa.pt/en/"),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
            child: InkWell(
              onTap: () => launch('http://www.apgeologos.pt/'),
              child: Row(
                children: <Widget>[
                  //Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),
                  Image.asset("images/partners/p2.png"),
                  Text("http://www.apgeologos.pt/",style: new TextStyle(color: Colors.blue)),

                ],
              ),
            ),
          ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.lapalmacentre.eu/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.lapalmacentre.eu/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p3.png"),
                        Text("https://www.lapalmacentre.eu/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('http://www.igme.es/'),
                    child: Row(
                      children: <Widget>[
                        //Text("http://www.igme.es/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p4.jpg"),
                        Text("http://www.igme.es/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.univ-brest.fr/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p5.jpg"),
                        Text("https://www.univ-brest.fr/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www2.bgs.ac.uk/gsni/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www2.bgs.ac.uk/gsni/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p6.jpg"),
                        Text("https://www2.bgs.ac.uk/gsni/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('http://www.lnec.pt/en/'),
                    child: Row(
                      children: <Widget>[
                        //Text("http://www.lnec.pt/en/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p7.jpg"),
                        Text("http://www.lnec.pt/en/",style: new TextStyle(color: Colors.blue)),
                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.ucd.ie/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.ucd.ie/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p8.jpg"),
                        Text("https://www.ucd.ie/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.cerema.fr/fr'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p9.jpg"),
                        Text("https://www.cerema.fr/fr",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.lneg.pt/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.lneg.pt/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p10.jpg"),
                        Text("https://www.lneg.pt/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.uma.pt/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.uma.pt/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p11.png"),
                        Text("https://www.uma.pt/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://www.ull.es/'),
                    child: Row(
                      children: <Widget>[
                        //Text("https://www.ull.es/",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p12.jpg"),
                        Text("https://www.ull.es/",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                Divider(
                    color: Colors.black
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('http://www.cm-lisboa.pt/en'),
                    child: Row(
                      children: <Widget>[
                        //Text("http://www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),
                        Image.asset("images/partners/p13.jpg"),
                        Text("http://www.cm-lisboa.pt/en",style: new TextStyle(color: Colors.blue)),

                      ],
                    ),
                  ),
                ),
                /*
                Expanded(child:Image(image: AssetImage('images/partners/p1.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p2.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p3.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p4.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p5.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p6.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p7.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p8.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p9.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p10.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p11.png',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p12.jpg',),),),
                Expanded(child:Image(image: AssetImage('images/partners/p13.jpg',),),),

                 */
                /*
                GestureDetector(
                  //onTap: _launchURL(1),
                  onTap: () => launch('https://google.com/'),
                  child: Image.asset(
                    'images/partners/p13.jpg', // On click should redirect to an URL
                    width: 400.0,
                    height: 180.0,
                    fit: BoxFit.cover,
                  ),
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => launch('https://google.com/'),
                    child: Stack(
                      children: <Widget>[
                        Image.asset("images/partners/p12.jpg"),
                        Text("https://google.com/"),
                      ],
                    ),
                  ),
                ),
                */
  ],
        ),)

         */







    );
  }
}