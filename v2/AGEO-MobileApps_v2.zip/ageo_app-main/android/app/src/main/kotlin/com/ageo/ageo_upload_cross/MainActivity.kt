package com.ageo.ageo_upload_cross

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
