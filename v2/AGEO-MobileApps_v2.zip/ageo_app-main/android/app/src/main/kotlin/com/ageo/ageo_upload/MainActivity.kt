package com.ageo.ageo_upload

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
